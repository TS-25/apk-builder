# APK Builder

A self-hosted platform that turns an uploaded ZIP of an Android, Expo, or
React Native project into a real APK — built entirely on your own server,
inside isolated Docker containers. No cloud build service (Expo's or
anyone else's) is used at any point.

```
USER → WEB FRONTEND → API SERVER → BUILD QUEUE → isolated Docker builder → APK → USER
```

## Contents

- [Architecture](#architecture)
- [Technology choices](#technology-choices)
- [Requirements](#requirements)
- [Installation](#installation)
- [Configuration](#configuration)
- [Building the builder images](#building-the-builder-images)
- [Starting the application](#starting-the-application)
- [Using the web interface](#using-the-web-interface)
- [Admin dashboard](#admin-dashboard)
- [Nginx & SSL](#nginx--ssl)
- [Security model](#security-model)
- [Troubleshooting](#troubleshooting)
- [Updating](#updating)
- [Backup](#backup)
- [Cleanup / retention](#cleanup--retention)
- [Extending with new build targets](#extending-with-new-build-targets)

## Architecture

```
apk-builder/
├── frontend/            React + Vite + TypeScript SPA
├── backend/              Node.js + TypeScript API server & worker
│   └── src/
│       ├── api/          REST routes (builds, admin, auth, SSE log stream)
│       ├── builders/      Builder interface + Android/Expo/RN implementations
│       ├── database/     SQLite schema & repositories
│       ├── queue/        BullMQ build queue, Redis log/cancel pub-sub
│       ├── security/     ZIP validation (traversal / bomb / symlink guards)
│       ├── services/     Docker container runner, error translator
│       └── workers/      Build orchestration (the actual build pipeline)
├── docker/
│   ├── android-builder/  Isolated image: JDK + Android SDK + Gradle
│   └── expo-builder/     Isolated image: above + Node/Yarn/pnpm
├── sample-projects/      Real, buildable Android & Expo sample apps
├── nginx/                Reverse proxy config (HTTPS, SSE, large uploads)
└── docker-compose.yml
```

**The web/API process never executes uploaded project code.** It validates
and stores the ZIP, then enqueues a job. Only the **worker** process talks
to Docker, and every build step (`npm install`, `gradle`, `npx expo
prebuild`, etc.) runs inside a fresh, non-privileged, resource-limited
container that only has the extracted project mounted at `/workspace` —
nothing else on the host.

### The builder abstraction

```ts
interface Builder {
  readonly type: ProjectType;
  canHandle(info: ProjectInfo): boolean;
  build(ctx: BuildContext, info: ProjectInfo): Promise<BuildOutputFile[]>;
}
```

`ProjectDetector` inspects the extracted archive and produces a
`ProjectInfo`; `registry.ts` picks the first `Builder` that can handle it.
Adding Flutter, Ionic, Capacitor, Cordova, or Kotlin Multiplatform support
later means writing one new class that implements `Builder` and adding it
to the array in `backend/src/builders/registry.ts` — nothing else changes.

## Technology choices

| Layer | Choice | Why |
|---|---|---|
| Backend | Node.js + TypeScript + Express | Excellent Docker API bindings (`dockerode`), first-class SSE/streaming support, easy to reason about for long-running build orchestration |
| Frontend | React + Vite + TypeScript | Fast dev loop, small production bundle, no framework lock-in |
| Database | SQLite (`better-sqlite3`) | Zero-ops for a self-hosted single-node deployment; the repository layer (`database/db.ts`) is plain SQL behind small functions, so swapping in Postgres later is a matter of changing the driver, not the app |
| Queue | Redis + BullMQ | Battle-tested job queue with retries/concurrency control; Redis pub/sub also carries live log lines and cancel signals between the API and worker processes |
| Build isolation | Docker (`dockerode`), no Docker socket in the public-facing `web` container | Untrusted project code (arbitrary `npm`/`gradle`/`npx` scripts) must never run with host access; only the non-public `worker` process can talk to Docker |
| Reverse proxy | Nginx | Mature SSE/WebSocket proxying, large upload support, straightforward Let's Encrypt integration |

## Requirements

- A Linux VPS: Ubuntu 22.04, Ubuntu 24.04, or Debian 12
- Docker Engine + Docker Compose plugin
- Recommended minimum: 4 CPU cores, 8 GB RAM, 40 GB disk (Android/Expo
  builds are CPU- and disk-hungry; more is better)

You do **not** need Java, the Android SDK, Gradle, Node.js, or Expo
installed on the host — everything runs inside Docker.

## Installation

```bash
git clone <this-repo-url> apk-builder
cd apk-builder
cp .env.example .env
```

Edit `.env` — at minimum review `MAX_UPLOAD_SIZE`, `BUILD_TIMEOUT`,
`MAX_CONCURRENT_BUILDS`, and the Java/Android/Node versions. Leave
`ADMIN_EMAIL`/`ADMIN_PASSWORD_HASH` blank for now if you just want to try
it locally; see [Admin dashboard](#admin-dashboard) to lock it down before
exposing the server publicly.

## Configuration

All configuration is environment variables, documented with defaults in
[`.env.example`](.env.example):

```env
NODE_ENV=production
PORT=3000

DATABASE_URL=./data/database.sqlite
MAX_UPLOAD_SIZE=500MB
BUILD_TIMEOUT=20m
MAX_CONCURRENT_BUILDS=2
BUILD_RETENTION_DAYS=7

MAX_CPU=2
MAX_MEMORY=4GB
```

> Note: the spec's illustrative `MAX_CPU`/`MAX_MEMORY` names are implemented
> as `BUILD_CPU_LIMIT` / `BUILD_MEMORY_LIMIT` in this codebase (see
> `.env.example`) — same purpose, per-build-container CPU and memory caps.

NODE_VERSION=22
JAVA_VERSION=17
ANDROID_PLATFORM_VERSION=35
ANDROID_BUILD_TOOLS_VERSION=35.0.0

REDIS_URL=redis://redis:6379

ADMIN_EMAIL=
ADMIN_PASSWORD_HASH=
```

Generate `ADMIN_PASSWORD_HASH`:

```bash
cd backend
node scripts/hash-password.js "your-password"
# paste the printed salt:hash value into .env
```

## Building the builder images

The Android and Expo/React Native builder images aren't long-running
services, so they live outside `docker-compose.yml` — the worker spins up a
fresh, disposable container from them for every build step via the Docker
API. Build (or rebuild, after changing Java/Android/Node versions in
`.env`) them with:

```bash
./scripts/build-images.sh
```

This produces `apk-builder/android-builder:latest` and
`apk-builder/expo-builder:latest`, matching the image names the worker
expects (`ANDROID_BUILDER_IMAGE` / `EXPO_BUILDER_IMAGE` in `.env`).

## Starting the application

```bash
docker compose build
docker compose up -d
```

Check status and logs:

```bash
docker compose ps
docker compose logs -f web
docker compose logs -f worker
```

The web UI is served on port 80 (via the `nginx` service). For local
testing without Nginx/HTTPS, the API alone is also published on
`localhost:3000`.

## Using the web interface

1. **Upload a project** — drag and drop a ZIP (or select one) on the
   Upload page, then **Start Build**. Only `.zip` files are accepted.
2. **Watch it build** — you're taken to the Build Details page, which shows
   the detected project type, a stage-based progress pipeline (Extract →
   Detect → Prepare → Dependencies → \[Prebuild\] → Build → Locate APK →
   Complete — no fake percentages, only real discrete stages), and a live
   terminal-style log fed over Server-Sent Events.
3. **Download the APK** — once the build succeeds, every generated APK
   (debug and/or release) is listed with filename, size, and variant, each
   with its own download button.
4. **Build History** lists every build ever run, with cancel/delete
   actions. **Dashboard** shows aggregate counts (total/success/failed/
   running/queued).

### Building a standard Android project

Zip the project root (the one containing `settings.gradle[.kts]`,
`build.gradle[.kts]`, `app/`, and optionally `gradlew`) and upload it. If
the project has its own Gradle Wrapper it's used as-is; otherwise the
builder image's own system Gradle is used automatically — see
[`sample-projects/android`](sample-projects/android) for a working example
either way.

### Building an Expo project

Zip the project root (containing `package.json` with an `expo` dependency,
and `app.json`/`app.config.js`). If there's no committed `android/`
directory, `expo prebuild --platform android` is run automatically inside
the container first. If you *have* committed native code, prebuild is
skipped and your native project is used as-is — the platform never
silently discards native customizations. See
[`sample-projects/expo`](sample-projects/expo).

### Building a React Native project

Zip a project with `react-native` in `package.json` and a committed
`android/` directory (React Native, unlike Expo, has no `prebuild` step —
if `android/` is missing you'll get a clear error asking you to commit it).

## Admin dashboard

Set `ADMIN_EMAIL` / `ADMIN_PASSWORD_HASH` in `.env` (see
[Configuration](#configuration)) and restart the `web` service to require
sign-in for `/api/admin/*`. Sign in from the **Settings** page. The
**Admin** page then shows live CPU/memory/disk usage, queue depth, active
build containers, and lets you trigger retention cleanup on demand.

If left unset, admin endpoints are open — fine for local testing, **not**
for a publicly reachable server.

## Nginx & SSL

`nginx/apk-builder.conf` is baked into the `nginx` service image (built
from `frontend/Dockerfile`, which also compiles the React frontend — so
the host never needs Node.js). It already sets `client_max_body_size`,
disables buffering and sets long read/send timeouts on `/api/builds/` for
SSE, and proxies everything else to the API.

To add HTTPS with Let's Encrypt (webroot method, compatible with the
baked-in config approach above):

```bash
# 1. Point apk-builder.example.com's DNS at this server, then:
docker run --rm \
  -v $(docker volume inspect --format '{{ .Mountpoint }}' apk-builder_certbot-www):/var/www/certbot \
  -v $(docker volume inspect --format '{{ .Mountpoint }}' apk-builder_certbot-conf):/etc/letsencrypt \
  certbot/certbot certonly --webroot -w /var/www/certbot \
  -d apk-builder.example.com

# 2. Add an HTTPS server block to nginx/apk-builder.conf pointing at
#    /etc/letsencrypt/live/apk-builder.example.com/{fullchain,privkey}.pem,
#    then rebuild:
docker compose build nginx
docker compose up -d nginx
```

Set up cert renewal with a cron job that re-runs the `certbot certonly`
command and rebuilds/restarts the `nginx` service.

## Security model

Uploaded projects are **untrusted code** — treated that way throughout:

- **ZIP validation before extraction** (`security/zipValidator.ts`): entry
  count limit, uncompressed-size limit, compression-ratio zip-bomb
  heuristic, path-traversal rejection, symlink rejection — checked once
  against the central directory before any bytes touch disk, and again
  defensively during extraction.
- **No direct execution on the host.** The `web`/API process only ever
  validates, stores, and enqueues. `npm`, `yarn`, `pnpm`, `npx`, `gradle`,
  `./gradlew`, and `expo` are only ever invoked inside a builder container.
- **Docker isolation per build step**: `Privileged: false`, `CapDrop: ALL`
  with only the minimum filesystem caps re-added, `no-new-privileges`,
  CPU/memory/PID limits, a `/tmp` tmpfs, and a hard wall-clock timeout that
  force-stops the container.
- **No Docker socket in the public-facing `web` container** — only the
  non-public `worker` service can talk to Docker, and it never runs
  untrusted code on its own filesystem, only inside the containers it
  spawns. Cancellation is relayed from `web` to `worker` over a Redis
  pub/sub channel rather than `web` calling Docker directly.
- **Downloads are validated against the build's own output directory**
  (no path traversal via the `:file` route param).
- **Rate limiting** on uploads, admin/auth, and general API traffic.
- **Passwords** are hashed with scrypt + a random salt, verified with a
  timing-safe comparison; sessions use `httpOnly`, `sameSite=strict`
  cookies.
- **Disk-space check** before every build starts; refuses to start rather
  than fail mid-build.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `permission denied` on `/var/run/docker.sock` | The `worker` container's process needs access to the Docker socket; on most distros this just works via the compose bind mount, but if you changed the Docker group GID on the host, rebuild the worker image or adjust socket permissions |
| Build fails with `Unsupported class file major version` | Project needs a different Java version — set `JAVA_VERSION` in `.env` and re-run `./scripts/build-images.sh` |
| `SDK location not found` | The builder image failed to install the Android SDK — check `docker compose logs` from the build step and re-run `./scripts/build-images.sh` |
| Out of memory during Gradle build | Raise `BUILD_MEMORY_LIMIT` in `.env`, rebuild images if needed, restart `worker` |
| `ENOSPC` / disk full | Free space or lower `BUILD_RETENTION_DAYS`; trigger cleanup from the Admin dashboard |
| Build always times out | Raise `BUILD_TIMEOUT`; first builds are slower (cold Gradle/npm caches) — subsequent builds on the same image are faster |
| Uploads over Nginx fail with 413 | Raise `client_max_body_size` in `nginx/apk-builder.conf` to match `MAX_UPLOAD_SIZE`, then `docker compose build nginx && docker compose up -d nginx` |
| Live logs don't stream, only appear at the end | Usually a proxy buffering issue — confirm you're going through the provided `nginx/apk-builder.conf` (it disables buffering on `/api/builds/`) rather than a different proxy config |
| `expo prebuild` fails | Usually an invalid `app.json`/`app.config.js`, or an Expo SDK version mismatch with dependencies — check the live log for the specific Expo/Metro error |
| React Native build says "no android/ directory" | React Native has no prebuild step like Expo — commit the native `android/` folder to your zip |

## Updating

```bash
git pull
docker compose build
./scripts/build-images.sh   # if Java/Android/Node versions changed
docker compose up -d
```

## Backup

Everything persisted lives in the `build-data` and `redis-data` Docker
volumes (SQLite database, build sources/outputs/logs, and the queue
state):

```bash
docker run --rm -v apk-builder_build-data:/data -v $(pwd):/backup \
  alpine tar czf /backup/apk-builder-data-$(date +%F).tar.gz -C /data .
```

## Cleanup / retention

Finished builds (never currently-running ones) older than
`BUILD_RETENTION_DAYS` are eligible for cleanup, which deletes their
source/output/log directories and database row. Trigger it manually from
the Admin dashboard, or on a schedule with cron:

```bash
0 3 * * * curl -s -X POST http://localhost:3000/api/admin/cleanup
```

## Extending with new build targets

Add Flutter, Ionic, Capacitor, Cordova, or Kotlin Multiplatform support
without touching the rest of the app:

1. Implement `Builder` in a new file under `backend/src/builders/`
   (`FlutterBuilder.ts`, etc.), following `AndroidBuilder.ts` as a
   template — build a new isolated Docker image under `docker/` for it if
   it needs a different toolchain.
2. Update `ProjectDetector` (`backend/src/builders/detector.ts`) to
   recognize the new project type's marker files.
3. Register an instance in `backend/src/builders/registry.ts`.

Nothing in the API, queue, database, or frontend needs to change — the
Build Details page and history already render whatever `ProjectType`
string comes back.
