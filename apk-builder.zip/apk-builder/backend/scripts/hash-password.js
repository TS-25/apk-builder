#!/usr/bin/env node
// Usage: node scripts/hash-password.js "your-password"
// Prints a value suitable for ADMIN_PASSWORD_HASH in .env

import crypto from "node:crypto";

const password = process.argv[2];
if (!password) {
  console.error('Usage: node scripts/hash-password.js "your-password"');
  process.exit(1);
}

const salt = crypto.randomBytes(16).toString("hex");
const hash = crypto.scryptSync(password, salt, 64).toString("hex");
console.log(`${salt}:${hash}`);
