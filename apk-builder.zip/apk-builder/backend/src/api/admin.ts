import { Router } from "express";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { config } from "../config.js";
import { db, buildsRepo } from "../database/db.js";
import { buildQueue } from "../queue/queue.js";

export const adminRouter = Router();

adminRouter.get("/stats", async (_req, res) => {
  const counts = db
    .prepare(
      `SELECT status, COUNT(*) as count FROM builds GROUP BY status`
    )
    .all() as { status: string; count: number }[];

  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const load = os.loadavg();

  let diskFreeBytes: number | null = null;
  let diskTotalBytes: number | null = null;
  try {
    const stat = fs.statfsSync(config.dataDir);
    diskFreeBytes = stat.bavail * stat.bsize;
    diskTotalBytes = stat.blocks * stat.bsize;
  } catch {
    /* statfs unsupported */
  }

  // The web process has no Docker socket access — only the worker does
  // (see docker-compose.yml). Each active build corresponds to exactly one
  // running builder container, so the queue's active-job count is an exact
  // stand-in for "active build containers" without needing Docker access here.
  const activeBuildContainers = await buildQueue.getActiveCount();

  res.json({
    builds: {
      byStatus: Object.fromEntries(counts.map((c) => [c.status, c.count])),
      queueWaiting: await buildQueue.getWaitingCount(),
      queueActive: await buildQueue.getActiveCount(),
    },
    resources: {
      cpuLoadAvg: load,
      cpuCount: os.cpus().length,
      memoryTotalBytes: totalMem,
      memoryFreeBytes: freeMem,
      diskTotalBytes,
      diskFreeBytes,
      activeBuildContainers,
    },
    config: {
      maxConcurrentBuilds: config.maxConcurrentBuilds,
      buildTimeoutMs: config.buildTimeoutMs,
      buildRetentionDays: config.buildRetentionDays,
      maxUploadBytes: config.maxUploadBytes,
    },
  });
});

adminRouter.post("/cleanup", async (_req, res) => {
  const cutoff = new Date(Date.now() - config.buildRetentionDays * 86400_000).toISOString();
  const stale = buildsRepo.listOlderThan(cutoff);
  let removed = 0;
  for (const b of stale) {
    try {
      fs.rmSync(path.dirname(b.source_path), { recursive: true, force: true });
      buildsRepo.delete(b.id);
      removed++;
    } catch {
      /* continue */
    }
  }
  res.json({ removed });
});
