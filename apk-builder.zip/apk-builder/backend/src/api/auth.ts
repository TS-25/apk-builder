import { Router, type Request, type Response, type NextFunction } from "express";
import crypto from "node:crypto";
import { config } from "../config.js";

export const authRouter = Router();

// Sessions kept in-memory: fine for a single-instance self-hosted deployment.
// Swap for a Redis-backed store if you scale the API horizontally.
const sessions = new Map<string, number>(); // token -> expiry epoch ms
const SESSION_TTL_MS = 12 * 60 * 60 * 1000;

function timingSafeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

function hashPassword(password: string, salt: string): string {
  return crypto.scryptSync(password, salt, 64).toString("hex");
}

/** ADMIN_PASSWORD_HASH format expected: "<salt>:<hex-hash>" produced by scrypt. */
function verifyPassword(password: string): boolean {
  if (!config.adminPasswordHash) return false;
  const [salt, hash] = config.adminPasswordHash.split(":");
  if (!salt || !hash) return false;
  const computed = hashPassword(password, salt);
  return timingSafeEqual(computed, hash);
}

authRouter.post("/login", (req: Request, res: Response) => {
  const { email, password } = req.body || {};
  if (!config.adminEmail || !config.adminPasswordHash) {
    return res.status(503).json({ error: "Admin authentication is not configured on this server" });
  }
  if (email !== config.adminEmail || typeof password !== "string" || !verifyPassword(password)) {
    return res.status(401).json({ error: "Invalid credentials" });
  }
  const token = crypto.randomBytes(32).toString("hex");
  sessions.set(token, Date.now() + SESSION_TTL_MS);
  res.cookie("session", token, {
    httpOnly: true,
    secure: config.nodeEnv === "production",
    sameSite: "strict",
    maxAge: SESSION_TTL_MS,
  });
  res.json({ ok: true });
});

authRouter.post("/logout", (req: Request, res: Response) => {
  const token = req.cookies?.session;
  if (token) sessions.delete(token);
  res.clearCookie("session");
  res.json({ ok: true });
});

export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!config.adminEmail || !config.adminPasswordHash) {
    // Admin auth not configured — for a first self-hosted install we allow
    // access but this should be configured before exposing the server publicly.
    return next();
  }
  const token = req.cookies?.session;
  const expiry = token ? sessions.get(token) : undefined;
  if (!expiry || expiry < Date.now()) {
    return res.status(401).json({ error: "Authentication required" });
  }
  next();
}
