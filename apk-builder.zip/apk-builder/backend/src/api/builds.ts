import { Router } from "express";
import multer from "multer";
import fs from "node:fs";
import path from "node:path";
import { nanoid } from "nanoid";
import { config } from "../config.js";
import { buildsRepo, logsRepo, outputsRepo } from "../database/db.js";
import { validateZip, ZipValidationError } from "../security/zipValidator.js";
import { buildQueue } from "../queue/queue.js";
import { publishCancel } from "../queue/cancelBus.js";
import { logger } from "../utils/logger.js";

export const buildsRouter = Router();

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => {
      fs.mkdirSync(config.buildsDir, { recursive: true });
      cb(null, config.buildsDir);
    },
    filename: (_req, _file, cb) => cb(null, `upload-${nanoid()}.zip`),
  }),
  limits: { fileSize: config.maxUploadBytes },
  fileFilter: (_req, file, cb) => {
    const isZip =
      file.mimetype === "application/zip" ||
      file.mimetype === "application/x-zip-compressed" ||
      file.originalname.toLowerCase().endsWith(".zip");
    if (!isZip) return cb(new Error("Only ZIP files are allowed"));
    cb(null, true);
  },
});

function freeDiskBytes(): number {
  try {
    const stat = fs.statfsSync(config.dataDir);
    return stat.bavail * stat.bsize;
  } catch {
    return Number.MAX_SAFE_INTEGER; // statfs unsupported on this platform; skip check
  }
}

buildsRouter.post("/", upload.single("project"), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "No ZIP file uploaded (field name: 'project')" });
  }

  const uploadedZipPath = req.file.path;

  // Minimum required free space: 3x the upload size, floor 1GB.
  const minRequired = Math.max(req.file.size * 3, 1024 ** 3);
  if (freeDiskBytes() < minRequired) {
    fs.rmSync(uploadedZipPath, { force: true });
    return res.status(507).json({ error: "Not enough server storage available to start this build." });
  }

  try {
    await validateZip(uploadedZipPath);
  } catch (err) {
    fs.rmSync(uploadedZipPath, { force: true });
    if (err instanceof ZipValidationError) {
      return res.status(400).json({ error: err.message });
    }
    logger.error({ err }, "zip validation error");
    return res.status(400).json({ error: "Invalid ZIP file" });
  }

  const buildId = nanoid(12);
  const buildRoot = path.join(config.buildsDir, buildId);
  const sourceDir = path.join(buildRoot, "source");
  const outputDir = path.join(buildRoot, "output");
  const logDir = path.join(buildRoot, "logs");
  fs.mkdirSync(buildRoot, { recursive: true });
  fs.mkdirSync(logDir, { recursive: true });

  // Move the validated zip next to source/ so the worker can extract it.
  const finalZipPath = path.join(buildRoot, "upload.zip");
  fs.renameSync(uploadedZipPath, finalZipPath);

  const projectName = (req.body?.projectName || req.file.originalname.replace(/\.zip$/i, "")).slice(0, 200);

  buildsRepo.insert({
    id: buildId,
    project_name: projectName,
    source_path: sourceDir,
    output_path: outputDir,
    log_path: logDir,
  });
  logsRepo.append(buildId, "Upload complete", "info");
  logsRepo.append(buildId, "Build queued", "info");

  const activeCount = await buildQueue.getActiveCount();
  const waitingCount = await buildQueue.getWaitingCount();
  if (activeCount + waitingCount >= config.maxConcurrentBuilds * 20) {
    return res.status(429).json({ error: "Build queue is full. Try again later." });
  }

  await buildQueue.add(
    "build",
    { buildId },
    { removeOnComplete: true, removeOnFail: true, attempts: 1 }
  );

  res.status(201).json({ id: buildId, status: "QUEUED" });
});

buildsRouter.get("/", async (req, res) => {
  const limit = Math.min(parseInt(String(req.query.limit || "50"), 10) || 50, 200);
  const offset = parseInt(String(req.query.offset || "0"), 10) || 0;
  const rows = buildsRepo.list(limit, offset);
  res.json(rows);
});

buildsRouter.get("/:id", (req, res) => {
  const rec = buildsRepo.get(req.params.id);
  if (!rec) return res.status(404).json({ error: "Build not found" });
  const outputs = outputsRepo.list(rec.id);
  res.json({ ...rec, outputs });
});

buildsRouter.get("/:id/status", (req, res) => {
  const rec = buildsRepo.get(req.params.id);
  if (!rec) return res.status(404).json({ error: "Build not found" });
  res.json({ id: rec.id, status: rec.status, stage: rec.stage });
});

buildsRouter.get("/:id/logs", (req, res) => {
  const rec = buildsRepo.get(req.params.id);
  if (!rec) return res.status(404).json({ error: "Build not found" });
  res.json(logsRepo.list(rec.id));
});

buildsRouter.get("/:id/output", (req, res) => {
  const rec = buildsRepo.get(req.params.id);
  if (!rec) return res.status(404).json({ error: "Build not found" });
  res.json(outputsRepo.list(rec.id));
});

buildsRouter.get("/:id/download/:file", (req, res) => {
  const rec = buildsRepo.get(req.params.id);
  if (!rec) return res.status(404).json({ error: "Build not found" });

  const requested = path.basename(req.params.file); // strip any path components
  const outputs = outputsRepo.list(rec.id) as any[];
  const match = outputs.find((o) => o.filename === requested);
  if (!match) return res.status(404).json({ error: "File not found for this build" });

  const resolved = path.resolve(match.path);
  const resolvedOutputDir = path.resolve(rec.output_path);
  if (!resolved.startsWith(resolvedOutputDir + path.sep)) {
    return res.status(400).json({ error: "Invalid file path" });
  }

  res.download(resolved, requested);
});

buildsRouter.post("/:id/cancel", async (req, res) => {
  const rec = buildsRepo.get(req.params.id);
  if (!rec) return res.status(404).json({ error: "Build not found" });

  if (["SUCCESS", "FAILED", "CANCELLED", "TIMEOUT"].includes(rec.status)) {
    return res.status(400).json({ error: "Build already finished" });
  }

  // The web process has no Docker socket access (only the worker does — see
  // docker-compose.yml). Signal the worker over Redis; it owns the
  // AbortController for this build and will stop its own container, update
  // the DB to CANCELLED, and publish the terminal log event itself.
  publishCancel(rec.id);
  logsRepo.append(rec.id, "Cancellation requested by user", "warn");
  res.json({ id: rec.id, status: "CANCELLING" });
});

buildsRouter.delete("/:id", (req, res) => {
  const rec = buildsRepo.get(req.params.id);
  if (!rec) return res.status(404).json({ error: "Build not found" });
  if (["QUEUED", "BUILDING", "PREPARING", "INSTALLING_DEPENDENCIES", "PREBUILD", "EXTRACTING", "DETECTING", "UPLOADING", "CANCELLING"].includes(rec.status)) {
    return res.status(400).json({ error: "Cannot delete a build that is currently running. Cancel it first." });
  }
  const buildRoot = path.dirname(rec.source_path);
  fs.rmSync(buildRoot, { recursive: true, force: true });
  buildsRepo.delete(rec.id);
  res.status(204).send();
});
