import { Router } from "express";
import { buildsRepo, logsRepo } from "../database/db.js";
import { subscribeToBuild } from "../queue/logBus.js";

export const sseRouter = Router();

sseRouter.get("/:id/stream", (req, res) => {
  const rec = buildsRepo.get(req.params.id);
  if (!rec) {
    res.status(404).end();
    return;
  }

  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no", // disable nginx buffering for SSE
  });

  // Replay existing logs first so late subscribers see full history.
  for (const row of logsRepo.list(rec.id) as any[]) {
    res.write(`data: ${JSON.stringify({ buildId: rec.id, message: row.message, level: row.level, ts: row.ts })}\n\n`);
  }

  const current = buildsRepo.get(rec.id);
  if (current && ["SUCCESS", "FAILED", "CANCELLED", "TIMEOUT"].includes(current.status)) {
    res.write(`data: ${JSON.stringify({ buildId: rec.id, message: "Stream closed", status: current.status, done: true })}\n\n`);
    res.end();
    return;
  }

  const unsubscribe = subscribeToBuild(rec.id, (event) => {
    res.write(`data: ${JSON.stringify(event)}\n\n`);
    if (event.done) {
      res.end();
    }
  });

  const keepAlive = setInterval(() => res.write(": keepalive\n\n"), 15000);

  req.on("close", () => {
    clearInterval(keepAlive);
    unsubscribe();
  });
});
