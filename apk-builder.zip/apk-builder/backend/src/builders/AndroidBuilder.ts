import fs from "node:fs";
import path from "node:path";
import { config } from "../config.js";
import { runInContainer } from "../services/dockerRunner.js";
import { resolveEffectiveRoot } from "./detector.js";
import type { Builder, BuildContext, BuildOutputFile, ProjectInfo } from "./types.js";

export class AndroidBuilder implements Builder {
  readonly type = "ANDROID" as const;

  canHandle(info: ProjectInfo): boolean {
    return info.type === "ANDROID";
  }

  async build(ctx: BuildContext, info: ProjectInfo): Promise<BuildOutputFile[]> {
    const root = resolveEffectiveRoot(ctx.sourceDir);
    const hasWrapper = fs.existsSync(path.join(root, "gradlew"));

    ctx.onStage("BUILDING");
    ctx.onLog(`Detected standard Android Gradle project`);
    ctx.onLog(hasWrapper ? "Using project's own Gradle Wrapper" : "No gradlew found; using container's system Gradle");

    const gradleCmd = hasWrapper ? "chmod +x ./gradlew && ./gradlew assembleDebug --no-daemon --stacktrace" : "gradle assembleDebug --no-daemon --stacktrace";

    const result = await runInContainer({
      image: config.androidBuilderImage,
      workdirHostPath: ctx.sourceDir,
      command: ["bash", "-lc", gradleCmd],
      env: {
        JAVA_VERSION: config.javaVersion,
        ANDROID_PLATFORM_VERSION: config.androidPlatformVersion,
        ANDROID_BUILD_TOOLS_VERSION: config.androidBuildToolsVersion,
        GRADLE_USER_HOME: "/tmp/.gradle",
      },
      timeoutMs: config.buildTimeoutMs,
      onLog: (chunk) => ctx.onLog(chunk.trimEnd()),
      signal: ctx.signal,
    });

    if (result.timedOut) throw new BuildTimeoutError();
    if (result.exitCode !== 0) throw new Error(`Gradle build failed with exit code ${result.exitCode}`);

    ctx.onStage("FINDING_APK");
    return findApks(root, ctx.outputDir);
  }
}

export class BuildTimeoutError extends Error {
  constructor(message = "Build exceeded the configured timeout") {
    super(message);
  }
}

/** Recursively locates generated APK files and copies them into the output dir. */
export function findApks(root: string, outputDir: string): BuildOutputFile[] {
  const candidates = [
    path.join(root, "app", "build", "outputs", "apk", "debug"),
    path.join(root, "app", "build", "outputs", "apk", "release"),
    path.join(root, "app", "build", "outputs", "apk"),
    path.join(root, "android", "app", "build", "outputs", "apk", "debug"),
    path.join(root, "android", "app", "build", "outputs", "apk", "release"),
    path.join(root, "android", "app", "build", "outputs", "apk"),
  ];

  const found: BuildOutputFile[] = [];
  const seen = new Set<string>();

  function scanDir(dir: string) {
    if (!fs.existsSync(dir)) return;
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        scanDir(full);
      } else if (entry.name.endsWith(".apk") && !seen.has(full)) {
        seen.add(full);
        const stat = fs.statSync(full);
        const destName = entry.name;
        const destPath = path.join(outputDir, destName);
        fs.mkdirSync(outputDir, { recursive: true });
        fs.copyFileSync(full, destPath);
        found.push({
          filename: destName,
          path: destPath,
          sizeBytes: stat.size,
          variant: destName.includes("release") ? "release" : "debug",
        });
      }
    }
  }

  for (const c of candidates) scanDir(c);

  if (found.length === 0) {
    throw new Error(
      "Build finished but no APK file was found in the expected output directories (app/build/outputs/apk/*)"
    );
  }
  return found;
}
