import fs from "node:fs";
import path from "node:path";
import { config } from "../config.js";
import { runInContainer } from "../services/dockerRunner.js";
import { resolveEffectiveRoot } from "./detector.js";
import { findApks, BuildTimeoutError } from "./AndroidBuilder.js";
import type { Builder, BuildContext, BuildOutputFile, ProjectInfo } from "./types.js";

function installCmd(pm: string | null): string {
  switch (pm) {
    case "yarn":
      return "yarn install --frozen-lockfile || yarn install";
    case "pnpm":
      return "pnpm install --frozen-lockfile || pnpm install";
    default:
      return "npm ci || npm install";
  }
}

export class ExpoBuilder implements Builder {
  readonly type = "EXPO" as const;

  canHandle(info: ProjectInfo): boolean {
    return info.type === "EXPO";
  }

  async build(ctx: BuildContext, info: ProjectInfo): Promise<BuildOutputFile[]> {
    const root = resolveEffectiveRoot(ctx.sourceDir);
    const relRoot = path.relative(ctx.sourceDir, root) || ".";
    const androidDirExists = fs.existsSync(path.join(root, "android"));

    ctx.onStage("INSTALLING_DEPENDENCIES");
    ctx.onLog(`Package manager: ${info.packageManager || "npm"}`);
    ctx.onLog(`Expo SDK: ${info.expoSdkVersion || "unknown"}`);

    const install = await runInContainer({
      image: config.expoBuilderImage,
      workdirHostPath: ctx.sourceDir,
      command: ["bash", "-lc", `cd "${relRoot}" && ${installCmd(info.packageManager)}`],
      env: { NODE_VERSION: info.nodeVersion || config.nodeVersion },
      timeoutMs: config.buildTimeoutMs,
      onLog: (chunk) => ctx.onLog(chunk.trimEnd()),
      signal: ctx.signal,
    });
    if (install.timedOut) throw new BuildTimeoutError();
    if (install.exitCode !== 0) throw new Error(`Dependency installation failed with exit code ${install.exitCode}`);

    // Only prebuild if there's no existing native android/ directory. If the
    // user already committed native code, respect it — prebuild could
    // silently discard native customizations.
    if (!androidDirExists) {
      ctx.onStage("PREBUILD");
      ctx.onLog("No existing android/ directory found — running `expo prebuild`");
      const prebuild = await runInContainer({
        image: config.expoBuilderImage,
        workdirHostPath: ctx.sourceDir,
        command: ["bash", "-lc", `cd "${relRoot}" && npx expo prebuild --platform android --non-interactive`],
        env: { NODE_VERSION: info.nodeVersion || config.nodeVersion, EXPO_NO_TELEMETRY: "1", CI: "1" },
        timeoutMs: config.buildTimeoutMs,
        onLog: (chunk) => ctx.onLog(chunk.trimEnd()),
        signal: ctx.signal,
      });
      if (prebuild.timedOut) throw new BuildTimeoutError();
      if (prebuild.exitCode !== 0) throw new Error(`expo prebuild failed with exit code ${prebuild.exitCode}`);
    } else {
      ctx.onLog("Existing android/ directory found — skipping prebuild, using committed native project");
    }

    if (!fs.existsSync(path.join(root, "android"))) {
      throw new Error("android/ directory still missing after prebuild — cannot continue");
    }

    ctx.onStage("BUILDING");
    const hasWrapper = fs.existsSync(path.join(root, "android", "gradlew"));
    const gradleCmd = hasWrapper
      ? `cd "${relRoot}/android" && chmod +x ./gradlew && ./gradlew assembleDebug --no-daemon --stacktrace`
      : `cd "${relRoot}/android" && gradle assembleDebug --no-daemon --stacktrace`;

    const build = await runInContainer({
      image: config.expoBuilderImage,
      workdirHostPath: ctx.sourceDir,
      command: ["bash", "-lc", gradleCmd],
      env: {
        JAVA_VERSION: config.javaVersion,
        ANDROID_PLATFORM_VERSION: config.androidPlatformVersion,
        ANDROID_BUILD_TOOLS_VERSION: config.androidBuildToolsVersion,
        GRADLE_USER_HOME: "/tmp/.gradle",
      },
      timeoutMs: config.buildTimeoutMs,
      onLog: (chunk) => ctx.onLog(chunk.trimEnd()),
      signal: ctx.signal,
    });
    if (build.timedOut) throw new BuildTimeoutError();
    if (build.exitCode !== 0) throw new Error(`Gradle build failed with exit code ${build.exitCode}`);

    ctx.onStage("FINDING_APK");
    return findApks(root, ctx.outputDir);
  }
}
