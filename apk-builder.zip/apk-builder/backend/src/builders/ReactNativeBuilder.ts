import fs from "node:fs";
import path from "node:path";
import { config } from "../config.js";
import { runInContainer } from "../services/dockerRunner.js";
import { resolveEffectiveRoot } from "./detector.js";
import { findApks, BuildTimeoutError } from "./AndroidBuilder.js";
import type { Builder, BuildContext, BuildOutputFile, ProjectInfo } from "./types.js";

function installCmd(pm: string | null): string {
  switch (pm) {
    case "yarn":
      return "yarn install --frozen-lockfile || yarn install";
    case "pnpm":
      return "pnpm install --frozen-lockfile || pnpm install";
    default:
      return "npm ci || npm install";
  }
}

export class ReactNativeBuilder implements Builder {
  readonly type = "REACT_NATIVE" as const;

  canHandle(info: ProjectInfo): boolean {
    return info.type === "REACT_NATIVE";
  }

  async build(ctx: BuildContext, info: ProjectInfo): Promise<BuildOutputFile[]> {
    const root = resolveEffectiveRoot(ctx.sourceDir);
    const relRoot = path.relative(ctx.sourceDir, root) || ".";

    ctx.onStage("INSTALLING_DEPENDENCIES");
    const install = await runInContainer({
      image: config.expoBuilderImage,
      workdirHostPath: ctx.sourceDir,
      command: ["bash", "-lc", `cd "${relRoot}" && ${installCmd(info.packageManager)}`],
      env: { NODE_VERSION: info.nodeVersion || config.nodeVersion },
      timeoutMs: config.buildTimeoutMs,
      onLog: (chunk) => ctx.onLog(chunk.trimEnd()),
      signal: ctx.signal,
    });
    if (install.timedOut) throw new BuildTimeoutError();
    if (install.exitCode !== 0) throw new Error(`Dependency installation failed with exit code ${install.exitCode}`);

    if (!fs.existsSync(path.join(root, "android"))) {
      throw new Error(
        "This React Native project has no android/ directory. Run `npx react-native init` locally or commit the android folder before uploading."
      );
    }

    ctx.onStage("BUILDING");
    const hasWrapper = fs.existsSync(path.join(root, "android", "gradlew"));
    const gradleCmd = hasWrapper
      ? `cd "${relRoot}/android" && chmod +x ./gradlew && ./gradlew assembleDebug --no-daemon --stacktrace`
      : `cd "${relRoot}/android" && gradle assembleDebug --no-daemon --stacktrace`;

    const build = await runInContainer({
      image: config.expoBuilderImage,
      workdirHostPath: ctx.sourceDir,
      command: ["bash", "-lc", gradleCmd],
      env: {
        JAVA_VERSION: config.javaVersion,
        ANDROID_PLATFORM_VERSION: config.androidPlatformVersion,
        ANDROID_BUILD_TOOLS_VERSION: config.androidBuildToolsVersion,
        GRADLE_USER_HOME: "/tmp/.gradle",
      },
      timeoutMs: config.buildTimeoutMs,
      onLog: (chunk) => ctx.onLog(chunk.trimEnd()),
      signal: ctx.signal,
    });
    if (build.timedOut) throw new BuildTimeoutError();
    if (build.exitCode !== 0) throw new Error(`Gradle build failed with exit code ${build.exitCode}`);

    ctx.onStage("FINDING_APK");
    return findApks(root, ctx.outputDir);
  }
}
