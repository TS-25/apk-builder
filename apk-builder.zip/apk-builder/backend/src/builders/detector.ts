import fs from "node:fs";
import path from "node:path";
import type { PackageManager, ProjectInfo, ProjectType } from "./types.js";

function exists(p: string): boolean {
  try {
    fs.accessSync(p);
    return true;
  } catch {
    return false;
  }
}

function readJsonSafe(p: string): any | null {
  try {
    return JSON.parse(fs.readFileSync(p, "utf-8"));
  } catch {
    return null;
  }
}

function detectPackageManager(dir: string): PackageManager {
  if (exists(path.join(dir, "pnpm-lock.yaml"))) return "pnpm";
  if (exists(path.join(dir, "yarn.lock"))) return "yarn";
  if (exists(path.join(dir, "package-lock.json"))) return "npm";
  if (exists(path.join(dir, "package.json"))) return "npm"; // sensible default
  return null;
}

function detectNodeVersion(dir: string, pkgJson: any | null): string | null {
  const nvmrc = path.join(dir, ".nvmrc");
  if (exists(nvmrc)) {
    const v = fs.readFileSync(nvmrc, "utf-8").trim();
    if (v) return v.replace(/^v/, "");
  }
  const engines = pkgJson?.engines?.node;
  if (engines) return String(engines).replace(/[^\d.]/g, "").split(".")[0] || null;
  return null;
}

/**
 * Detects the project type by inspecting well-known marker files. Order of
 * checks matters: Expo is checked before generic React Native because every
 * Expo project also depends on react-native.
 */
export function detectProject(sourceDir: string): ProjectInfo {
  // Some archives wrap everything in a single top-level folder; unwrap it.
  const root = resolveEffectiveRoot(sourceDir);

  const pkgJsonPath = path.join(root, "package.json");
  const pkgJson = exists(pkgJsonPath) ? readJsonSafe(pkgJsonPath) : null;

  const hasGradlew = exists(path.join(root, "gradlew")) || exists(path.join(root, "android", "gradlew"));
  const hasSettingsGradle =
    exists(path.join(root, "settings.gradle")) ||
    exists(path.join(root, "settings.gradle.kts")) ||
    exists(path.join(root, "android", "settings.gradle")) ||
    exists(path.join(root, "android", "settings.gradle.kts"));
  const hasAndroidDir = exists(path.join(root, "android")) || (hasGradlew && exists(path.join(root, "app")));

  const deps: Record<string, string> = {
    ...(pkgJson?.dependencies || {}),
    ...(pkgJson?.devDependencies || {}),
  };

  const isExpo =
    !!deps["expo"] ||
    exists(path.join(root, "app.json")) && !!readJsonSafe(path.join(root, "app.json"))?.expo ||
    exists(path.join(root, "app.config.js")) ||
    exists(path.join(root, "app.config.ts")) ||
    Object.keys(deps).some((d) => d.startsWith("expo-"));

  const isReactNative = !!deps["react-native"];

  let type: ProjectType = "UNKNOWN";
  if (isExpo) type = "EXPO";
  else if (isReactNative) type = "REACT_NATIVE";
  // Note: gradlew is NOT required for detection — AndroidBuilder falls back
  // to the container's own system Gradle when a project has no wrapper.
  else if (hasSettingsGradle || hasGradlew || hasAndroidDir) type = "ANDROID";

  const expoSdkVersion = deps["expo"] ? deps["expo"].replace(/[^\d.^~]/g, "").replace(/^[^\d]*/, "") : null;

  const androidManifestPkg = findAndroidPackageId(root);

  return {
    type,
    projectName: pkgJson?.name || path.basename(root) || "project",
    packageManager: detectPackageManager(root),
    nodeVersion: detectNodeVersion(root, pkgJson),
    expoSdkVersion,
    hasAndroidDir,
    packageId: androidManifestPkg,
    appVersion: pkgJson?.version || null,
  };
}

/** If the zip extracted into a single wrapping directory, dive into it. */
function resolveEffectiveRoot(dir: string): string {
  const entries = fs.readdirSync(dir, { withFileTypes: true }).filter((e) => !e.name.startsWith("__MACOSX"));
  if (entries.length === 1 && entries[0].isDirectory()) {
    return resolveEffectiveRoot(path.join(dir, entries[0].name));
  }
  return dir;
}

function findAndroidPackageId(root: string): string | null {
  const gradlePath = path.join(root, "android", "app", "build.gradle");
  const gradleKtsPath = path.join(root, "android", "app", "build.gradle.kts");
  for (const p of [gradlePath, gradleKtsPath, path.join(root, "app", "build.gradle")]) {
    if (exists(p)) {
      const content = fs.readFileSync(p, "utf-8");
      const m = /applicationId\s*[=(]?\s*["']([\w.]+)["']/.exec(content);
      if (m) return m[1];
    }
  }
  return null;
}

export { resolveEffectiveRoot };
