import { AndroidBuilder } from "./AndroidBuilder.js";
import { ExpoBuilder } from "./ExpoBuilder.js";
import { ReactNativeBuilder } from "./ReactNativeBuilder.js";
import type { Builder, ProjectInfo } from "./types.js";

// To add a new platform (Flutter, Ionic, Capacitor, Cordova, KMP...):
// 1. Implement the Builder interface in its own file.
// 2. Add an instance to this array. Nothing else changes.
const builders: Builder[] = [new AndroidBuilder(), new ExpoBuilder(), new ReactNativeBuilder()];

export function getBuilderFor(info: ProjectInfo): Builder {
  const builder = builders.find((b) => b.canHandle(info));
  if (!builder) {
    throw new Error(
      `Unsupported or undetected project type. Expected an Android, Expo, or React Native project (found package.json/app.json/gradlew markers did not match any known type).`
    );
  }
  return builder;
}
