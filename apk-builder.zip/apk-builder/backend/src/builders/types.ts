export type ProjectType = "ANDROID" | "EXPO" | "REACT_NATIVE" | "UNKNOWN";

export type PackageManager = "npm" | "yarn" | "pnpm" | null;

export interface ProjectInfo {
  type: ProjectType;
  projectName: string;
  packageManager: PackageManager;
  nodeVersion: string | null;
  expoSdkVersion: string | null;
  hasAndroidDir: boolean;
  packageId: string | null;
  appVersion: string | null;
}

export interface BuildContext {
  buildId: string;
  sourceDir: string; // .../builds/<id>/source
  outputDir: string; // .../builds/<id>/output
  logDir: string; // .../builds/<id>/logs
  onLog: (line: string, level?: "info" | "warn" | "error") => void;
  onStage: (stage: string) => void;
  signal: AbortSignal;
}

export interface BuildOutputFile {
  filename: string;
  path: string;
  sizeBytes: number;
  variant?: string;
}

/**
 * Common interface every project builder must implement. Adding a new
 * platform (Flutter, Ionic, Capacitor, Cordova, KMP, ...) means writing one
 * new class that implements this interface and registering it in the
 * detector — nothing else in the system needs to change.
 */
export interface Builder {
  readonly type: ProjectType;

  /** Confirms this builder can actually handle the detected project. */
  canHandle(info: ProjectInfo): boolean;

  /** Runs the full build inside an isolated Docker container and returns produced files. */
  build(ctx: BuildContext, info: ProjectInfo): Promise<BuildOutputFile[]>;
}
