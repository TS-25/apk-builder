import "dotenv/config";
import path from "node:path";

function envInt(name: string, fallback: number): number {
  const v = process.env[name];
  if (!v) return fallback;
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : fallback;
}

function parseSize(input: string | undefined, fallbackBytes: number): number {
  if (!input) return fallbackBytes;
  const m = /^(\d+(?:\.\d+)?)\s*(B|KB|MB|GB)?$/i.exec(input.trim());
  if (!m) return fallbackBytes;
  const n = parseFloat(m[1]);
  const unit = (m[2] || "B").toUpperCase();
  const mult = unit === "GB" ? 1024 ** 3 : unit === "MB" ? 1024 ** 2 : unit === "KB" ? 1024 : 1;
  return Math.floor(n * mult);
}

function parseDuration(input: string | undefined, fallbackMs: number): number {
  if (!input) return fallbackMs;
  const m = /^(\d+)\s*(ms|s|m|h)?$/i.exec(input.trim());
  if (!m) return fallbackMs;
  const n = parseInt(m[1], 10);
  const unit = (m[2] || "m").toLowerCase();
  const mult = unit === "h" ? 3600_000 : unit === "m" ? 60_000 : unit === "s" ? 1000 : 1;
  return n * mult;
}

const DATA_DIR = process.env.DATA_DIR || path.resolve(process.cwd(), "data");
const BUILDS_DIR = process.env.BUILDS_DIR || path.join(DATA_DIR, "builds");

export const config = {
  nodeEnv: process.env.NODE_ENV || "production",
  port: envInt("PORT", 3000),

  dataDir: DATA_DIR,
  buildsDir: BUILDS_DIR,
  databaseUrl: process.env.DATABASE_URL || path.join(DATA_DIR, "database.sqlite"),

  redisUrl: process.env.REDIS_URL || "redis://redis:6379",

  maxUploadBytes: parseSize(process.env.MAX_UPLOAD_SIZE, 500 * 1024 * 1024),
  buildTimeoutMs: parseDuration(process.env.BUILD_TIMEOUT, 20 * 60_000),
  maxConcurrentBuilds: envInt("MAX_CONCURRENT_BUILDS", 2),
  buildRetentionDays: envInt("BUILD_RETENTION_DAYS", 7),

  // ZIP safety limits
  maxZipEntries: envInt("MAX_ZIP_ENTRIES", 20000),
  maxUncompressedBytes: parseSize(process.env.MAX_UNCOMPRESSED_SIZE, 2 * 1024 * 1024 * 1024),
  maxCompressionRatio: envInt("MAX_COMPRESSION_RATIO", 100),
  // Separate from buildTimeoutMs (which only guards the Docker build step):
  // extraction runs before any container starts, so it needs its own bound
  // or a hang there (large archive, disk I/O stall, etc.) blocks the build
  // forever with no timeout ever kicking in.
  extractionTimeoutMs: parseDuration(process.env.EXTRACTION_TIMEOUT, 5 * 60_000),

  // container resource limits
  containerCpus: process.env.BUILD_CPU_LIMIT || "2",
  containerMemory: process.env.BUILD_MEMORY_LIMIT || "4g",
  containerPidsLimit: envInt("BUILD_PIDS_LIMIT", 512),

  androidBuilderImage: process.env.ANDROID_BUILDER_IMAGE || "apk-builder/android-builder:latest",
  expoBuilderImage: process.env.EXPO_BUILDER_IMAGE || "apk-builder/expo-builder:latest",

  javaVersion: process.env.JAVA_VERSION || "17",
  nodeVersion: process.env.NODE_VERSION || "22",
  androidPlatformVersion: process.env.ANDROID_PLATFORM_VERSION || "35",
  androidBuildToolsVersion: process.env.ANDROID_BUILD_TOOLS_VERSION || "35.0.0",

  adminEmail: process.env.ADMIN_EMAIL || "",
  adminPasswordHash: process.env.ADMIN_PASSWORD_HASH || "",
  jwtSecret: process.env.JWT_SECRET || "",
};

export function assertProductionSecrets() {
  if (config.nodeEnv === "production" && !config.jwtSecret) {
    // eslint-disable-next-line no-console
    console.warn(
      "[config] WARNING: JWT_SECRET is not set. Set a strong random value in production."
    );
  }
}
