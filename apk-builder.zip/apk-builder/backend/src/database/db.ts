import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";
import { config } from "../config.js";

fs.mkdirSync(path.dirname(config.databaseUrl), { recursive: true });

export const db = new Database(config.databaseUrl);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS builds (
  id              TEXT PRIMARY KEY,
  project_name    TEXT NOT NULL,
  project_type    TEXT NOT NULL DEFAULT 'UNKNOWN',
  status          TEXT NOT NULL DEFAULT 'QUEUED',
  stage           TEXT NOT NULL DEFAULT 'QUEUED',
  error_message   TEXT,
  source_path     TEXT NOT NULL,
  output_path     TEXT NOT NULL,
  log_path        TEXT NOT NULL,
  meta_json       TEXT NOT NULL DEFAULT '{}',
  created_at      TEXT NOT NULL DEFAULT (datetime('now')),
  started_at      TEXT,
  completed_at    TEXT
);

CREATE TABLE IF NOT EXISTS build_outputs (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  build_id    TEXT NOT NULL REFERENCES builds(id) ON DELETE CASCADE,
  filename    TEXT NOT NULL,
  path        TEXT NOT NULL,
  size_bytes  INTEGER NOT NULL,
  variant     TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS build_logs (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  build_id    TEXT NOT NULL REFERENCES builds(id) ON DELETE CASCADE,
  ts          TEXT NOT NULL DEFAULT (datetime('now')),
  level       TEXT NOT NULL DEFAULT 'info',
  message     TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_build_logs_build_id ON build_logs(build_id);

CREATE TABLE IF NOT EXISTS settings (
  key    TEXT PRIMARY KEY,
  value  TEXT NOT NULL
);
`);

export type BuildStatus =
  | "QUEUED"
  | "UPLOADING"
  | "EXTRACTING"
  | "DETECTING"
  | "PREPARING"
  | "INSTALLING_DEPENDENCIES"
  | "PREBUILD"
  | "BUILDING"
  | "FINDING_APK"
  | "SUCCESS"
  | "FAILED"
  | "CANCELLING"
  | "CANCELLED"
  | "TIMEOUT";

export interface BuildRecord {
  id: string;
  project_name: string;
  project_type: string;
  status: BuildStatus;
  stage: string;
  error_message: string | null;
  source_path: string;
  output_path: string;
  log_path: string;
  meta_json: string;
  created_at: string;
  started_at: string | null;
  completed_at: string | null;
}

export const buildsRepo = {
  insert(rec: Pick<BuildRecord, "id" | "project_name" | "source_path" | "output_path" | "log_path">) {
    db.prepare(
      `INSERT INTO builds (id, project_name, source_path, output_path, log_path) VALUES (?, ?, ?, ?, ?)`
    ).run(rec.id, rec.project_name, rec.source_path, rec.output_path, rec.log_path);
  },
  get(id: string): BuildRecord | undefined {
    return db.prepare(`SELECT * FROM builds WHERE id = ?`).get(id) as BuildRecord | undefined;
  },
  list(limit = 100, offset = 0): BuildRecord[] {
    return db
      .prepare(`SELECT * FROM builds ORDER BY created_at DESC LIMIT ? OFFSET ?`)
      .all(limit, offset) as BuildRecord[];
  },
  updateStatus(id: string, status: BuildStatus, stage?: string) {
    db.prepare(`UPDATE builds SET status = ?, stage = COALESCE(?, stage) WHERE id = ?`).run(
      status,
      stage ?? null,
      id
    );
  },
  setStarted(id: string) {
    db.prepare(`UPDATE builds SET started_at = datetime('now') WHERE id = ?`).run(id);
  },
  setCompleted(id: string, status: BuildStatus, errorMessage?: string) {
    db.prepare(
      `UPDATE builds SET status = ?, completed_at = datetime('now'), error_message = ? WHERE id = ?`
    ).run(status, errorMessage ?? null, id);
  },
  setProjectType(id: string, type: string) {
    db.prepare(`UPDATE builds SET project_type = ? WHERE id = ?`).run(type, id);
  },
  setMeta(id: string, meta: Record<string, unknown>) {
    db.prepare(`UPDATE builds SET meta_json = ? WHERE id = ?`).run(JSON.stringify(meta), id);
  },
  delete(id: string) {
    db.prepare(`DELETE FROM builds WHERE id = ?`).run(id);
  },
  listOlderThan(iso: string): BuildRecord[] {
    return db
      .prepare(`SELECT * FROM builds WHERE created_at < ? AND status NOT IN ('QUEUED','BUILDING','PREPARING','INSTALLING_DEPENDENCIES','PREBUILD','EXTRACTING','DETECTING','UPLOADING')`)
      .all(iso) as BuildRecord[];
  },
};

export const outputsRepo = {
  insert(buildId: string, filename: string, filePath: string, sizeBytes: number, variant?: string) {
    db.prepare(
      `INSERT INTO build_outputs (build_id, filename, path, size_bytes, variant) VALUES (?, ?, ?, ?, ?)`
    ).run(buildId, filename, filePath, sizeBytes, variant ?? null);
  },
  list(buildId: string) {
    return db.prepare(`SELECT * FROM build_outputs WHERE build_id = ?`).all(buildId);
  },
};

export const logsRepo = {
  append(buildId: string, message: string, level: "info" | "warn" | "error" = "info") {
    db.prepare(`INSERT INTO build_logs (build_id, level, message) VALUES (?, ?, ?)`).run(
      buildId,
      level,
      message
    );
  },
  list(buildId: string) {
    return db
      .prepare(`SELECT ts, level, message FROM build_logs WHERE build_id = ? ORDER BY id ASC`)
      .all(buildId);
  },
};
