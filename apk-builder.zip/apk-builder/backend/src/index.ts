import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
// pino-http ships CJS type declarations that don't resolve to a callable
// default under `moduleResolution: NodeNext` (a known interop gap between
// esModuleInterop and NodeNext's ESM/CJS type resolution — the runtime
// value is fine, only the type-checker gets confused). `import ... =
// require(...)` is TS's supported escape hatch for exactly this case: it
// still emits real ESM-compatible code (via a `createRequire` shim) but
// resolves types the same way a plain CJS `require` would.
import pinoHttp = require("pino-http");
import cookieParser from "cookie-parser";
import { config, assertProductionSecrets } from "./config.js";
import { logger } from "./utils/logger.js";
import { buildsRouter } from "./api/builds.js";
import { sseRouter } from "./api/sse.js";
import { adminRouter } from "./api/admin.js";
import { authRouter, requireAdmin } from "./api/auth.js";

assertProductionSecrets();

const app = express();

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || true, credentials: true }));
app.use(cookieParser());
app.use(express.json({ limit: "1mb" }));
app.use(pinoHttp({ logger }));

// General API rate limit.
app.use(
  "/api/",
  rateLimit({ windowMs: 60_000, max: 300, standardHeaders: true, legacyHeaders: false })
);

// Tighter limits on sensitive/expensive endpoints.
const uploadLimiter = rateLimit({ windowMs: 60_000, max: 10, standardHeaders: true, legacyHeaders: false });
const loginLimiter = rateLimit({ windowMs: 60_000, max: 10, standardHeaders: true, legacyHeaders: false });
const downloadLimiter = rateLimit({ windowMs: 60_000, max: 60, standardHeaders: true, legacyHeaders: false });

app.get("/api/health", (_req, res) => res.json({ ok: true }));

app.use("/api/auth", loginLimiter, authRouter);
app.post("/api/builds", uploadLimiter);
app.get("/api/builds/:id/download/:file", downloadLimiter);
app.use("/api/builds", buildsRouter);
app.use("/api/builds", sseRouter);
app.use("/api/admin", requireAdmin, adminRouter);

// Central error handler — never leak stack traces to clients.
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  logger.error({ err }, "unhandled request error");
  if (err?.type === "entity.too.large" || err?.code === "LIMIT_FILE_SIZE") {
    return res.status(413).json({ error: "Uploaded file exceeds the maximum allowed size" });
  }
  res.status(500).json({ error: "Internal server error" });
});

app.listen(config.port, () => {
  logger.info(`APK Builder API listening on port ${config.port}`);
});
