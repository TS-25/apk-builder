// See utils/cjsInterop.ts — ioredis has the same NodeNext type-resolution
// gap as pino-http; createRequire sidesteps it regardless of import style.
import { loadCjs } from "../utils/cjsInterop.js";
import { config } from "../config.js";

type RedisClient = {
  publish(channel: string, message: string): Promise<number>;
  subscribe(channel: string): Promise<unknown>;
  unsubscribe(channel: string): Promise<unknown>;
  disconnect(): void;
  on(event: "message", listener: (channel: string, message: string) => void): void;
};
const IORedis = loadCjs<new (url: string, opts?: Record<string, unknown>) => RedisClient>("ioredis");

const CHANNEL = "build-cancel";

// The `web` container intentionally has NO Docker socket access (see
// docker-compose.yml) — only `worker` does. So the cancel endpoint can't
// call `docker.stop()` directly from the API process. Instead it publishes
// a cancel signal over Redis; the worker (which owns the AbortController
// for the in-flight build and DOES have Docker access) picks it up and
// stops its own container. This keeps Docker socket access confined to a
// single, non-public-facing service.
const publisher = new IORedis(config.redisUrl, { maxRetriesPerRequest: null });

export function publishCancel(buildId: string) {
  publisher.publish(CHANNEL, buildId);
}

/** Worker-side: calls onCancel(buildId) whenever any client requests a cancel. */
export function subscribeCancel(onCancel: (buildId: string) => void): () => void {
  const sub = new IORedis(config.redisUrl, { maxRetriesPerRequest: null });
  sub.subscribe(CHANNEL).catch(() => {});
  sub.on("message", (_ch: string, buildId: string) => onCancel(buildId));
  return () => {
    sub.unsubscribe(CHANNEL).catch(() => {});
    sub.disconnect();
  };
}
