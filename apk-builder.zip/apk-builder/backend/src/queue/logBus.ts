// See queue/cancelBus.ts and utils/cjsInterop.ts for why ioredis is loaded
// this way instead of a normal import.
import { loadCjs } from "../utils/cjsInterop.js";
import { config } from "../config.js";

type RedisClient = {
  publish(channel: string, message: string): Promise<number>;
  subscribe(channel: string): Promise<unknown>;
  unsubscribe(channel: string): Promise<unknown>;
  disconnect(): void;
  on(event: "message", listener: (channel: string, message: string) => void): void;
};
const IORedis = loadCjs<new (url: string, opts?: Record<string, unknown>) => RedisClient>("ioredis");

const CHANNEL_PREFIX = "build-log:";

export interface LogEvent {
  buildId: string;
  message: string;
  level: "info" | "warn" | "error";
  stage?: string;
  status?: string;
  done?: boolean;
}

const publisher = new IORedis(config.redisUrl, { maxRetriesPerRequest: null });

export function publishLog(event: LogEvent) {
  publisher.publish(CHANNEL_PREFIX + event.buildId, JSON.stringify(event));
}

/** Subscribes to live log events for one build. Returns an unsubscribe function. */
export function subscribeToBuild(buildId: string, onEvent: (e: LogEvent) => void): () => void {
  const sub = new IORedis(config.redisUrl, { maxRetriesPerRequest: null });
  const channel = CHANNEL_PREFIX + buildId;
  sub.subscribe(channel).catch(() => {});
  sub.on("message", (_ch: string, message: string) => {
    try {
      onEvent(JSON.parse(message));
    } catch {
      /* ignore malformed */
    }
  });
  return () => {
    sub.unsubscribe(channel).catch(() => {});
    sub.disconnect();
  };
}
