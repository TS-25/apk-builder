// See queue/cancelBus.ts for why this is `import ... = require(...)`
// rather than a normal default import (NodeNext + ioredis CJS interop gap).
import IORedis = require("ioredis");
import { config } from "../config.js";

const CHANNEL_PREFIX = "build-log:";

export interface LogEvent {
  buildId: string;
  message: string;
  level: "info" | "warn" | "error";
  stage?: string;
  status?: string;
  done?: boolean;
}

const publisher = new IORedis(config.redisUrl, { maxRetriesPerRequest: null });

export function publishLog(event: LogEvent) {
  publisher.publish(CHANNEL_PREFIX + event.buildId, JSON.stringify(event));
}

/** Subscribes to live log events for one build. Returns an unsubscribe function. */
export function subscribeToBuild(buildId: string, onEvent: (e: LogEvent) => void): () => void {
  const sub = new IORedis(config.redisUrl, { maxRetriesPerRequest: null });
  const channel = CHANNEL_PREFIX + buildId;
  sub.subscribe(channel).catch(() => {});
  sub.on("message", (_ch: string, message: string) => {
    try {
      onEvent(JSON.parse(message));
    } catch {
      /* ignore malformed */
    }
  });
  return () => {
    sub.unsubscribe(channel).catch(() => {});
    sub.disconnect();
  };
}
