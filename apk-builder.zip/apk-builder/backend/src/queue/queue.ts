import { Queue } from "bullmq";
// See queue/cancelBus.ts for why this is `import ... = require(...)`
// rather than a normal default import (NodeNext + ioredis CJS interop gap).
import IORedis = require("ioredis");
import { config } from "../config.js";

export const connection = new IORedis(config.redisUrl, { maxRetriesPerRequest: null });

export interface BuildJobData {
  buildId: string;
}

export const buildQueue = new Queue<BuildJobData>("builds", { connection });
