import { Queue } from "bullmq";
// See queue/cancelBus.ts and utils/cjsInterop.ts for why ioredis is loaded
// this way instead of a normal import. Left as `any` here (rather than the
// structural RedisClient type used in cancelBus.ts/logBus.ts) because
// BullMQ's `Queue` constructor expects an actual ioredis `Redis` instance
// for its `connection` option, which our structural type can't satisfy —
// `any` is freely assignable and this is the one place the real ioredis
// instance shape (reconnection, cluster support, etc.) actually matters.
import { loadCjs } from "../utils/cjsInterop.js";
import { config } from "../config.js";

const IORedis = loadCjs<new (url: string, opts?: Record<string, unknown>) => any>("ioredis");

export const connection = new IORedis(config.redisUrl, { maxRetriesPerRequest: null });

export interface BuildJobData {
  buildId: string;
}

export const buildQueue = new Queue<BuildJobData>("builds", { connection });
