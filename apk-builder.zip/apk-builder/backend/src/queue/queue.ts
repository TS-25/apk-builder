import { Queue } from "bullmq";
import IORedis from "ioredis";
import { config } from "../config.js";

export const connection = new IORedis(config.redisUrl, { maxRetriesPerRequest: null });

export interface BuildJobData {
  buildId: string;
}

export const buildQueue = new Queue<BuildJobData>("builds", { connection });
