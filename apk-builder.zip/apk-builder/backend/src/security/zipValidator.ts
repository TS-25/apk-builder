import yauzl from "yauzl";
import path from "node:path";
import fs from "node:fs";
import { config } from "../config.js";

export class ZipValidationError extends Error {}

interface ZipEntryInfo {
  fileName: string;
  uncompressedSize: number;
  compressedSize: number;
}

/**
 * Opens the zip strictly and walks every central-directory entry WITHOUT
 * extracting anything, so we can reject dangerous archives before any
 * bytes touch disk.
 */
function readCentralDirectory(zipPath: string): Promise<ZipEntryInfo[]> {
  return new Promise((resolve, reject) => {
    const entries: ZipEntryInfo[] = [];
    yauzl.open(zipPath, { lazyEntries: true, strictFileNames: true }, (err, zip) => {
      if (err || !zip) return reject(new ZipValidationError("Not a valid ZIP file"));

      let count = 0;
      zip.on("entry", (entry) => {
        count++;
        if (count > config.maxZipEntries) {
          zip.close();
          return reject(new ZipValidationError(`ZIP contains too many entries (> ${config.maxZipEntries})`));
        }
        entries.push({
          fileName: entry.fileName,
          uncompressedSize: entry.uncompressedSize,
          compressedSize: entry.compressedSize,
        });
        zip.readEntry();
      });
      zip.on("end", () => resolve(entries));
      zip.on("error", () => reject(new ZipValidationError("Corrupt or malicious ZIP file")));
      zip.readEntry();
    });
  });
}

function isSafeRelativePath(entryPath: string): boolean {
  if (entryPath.startsWith("/") || entryPath.startsWith("\\")) return false;
  // Windows drive letters, e.g. C:\
  if (/^[a-zA-Z]:/.test(entryPath)) return false;
  const normalized = path.normalize(entryPath);
  if (normalized.split(/[\\/]/).includes("..")) return false;
  if (normalized.startsWith("..")) return false;
  return true;
}

/**
 * Validates a ZIP file against path traversal, zip-bomb ratio, entry-count
 * and uncompressed-size limits. Throws ZipValidationError on any violation.
 * Returns the validated entry list on success.
 */
export async function validateZip(zipPath: string): Promise<ZipEntryInfo[]> {
  const stat = fs.statSync(zipPath);
  if (stat.size === 0) throw new ZipValidationError("Uploaded file is empty");

  const entries = await readCentralDirectory(zipPath);
  if (entries.length === 0) throw new ZipValidationError("ZIP file contains no entries");

  let totalUncompressed = 0;
  let totalCompressed = 0;

  for (const entry of entries) {
    if (!isSafeRelativePath(entry.fileName)) {
      throw new ZipValidationError(`Unsafe path in archive: ${entry.fileName}`);
    }
    totalUncompressed += entry.uncompressedSize;
    totalCompressed += entry.compressedSize;

    if (totalUncompressed > config.maxUncompressedBytes) {
      throw new ZipValidationError("Uncompressed size of ZIP exceeds the configured limit");
    }
  }

  // Zip-bomb heuristic: overall compression ratio.
  if (totalCompressed > 0) {
    const ratio = totalUncompressed / totalCompressed;
    if (ratio > config.maxCompressionRatio) {
      throw new ZipValidationError(
        `ZIP compression ratio (${ratio.toFixed(0)}:1) exceeds the safety limit — possible zip bomb`
      );
    }
  }

  return entries;
}

/**
 * Safely extracts a previously-validated ZIP into destDir.
 * Re-validates every entry path again at extraction time (defense in depth)
 * and rejects symlinks.
 */
export function extractZipSafely(zipPath: string, destDir: string): Promise<void> {
  return new Promise((resolve, reject) => {
    fs.mkdirSync(destDir, { recursive: true });
    yauzl.open(zipPath, { lazyEntries: true, strictFileNames: true }, (err, zip) => {
      if (err || !zip) return reject(new ZipValidationError("Not a valid ZIP file"));

      zip.on("entry", (entry) => {
        const fileName = entry.fileName;

        if (!isSafeRelativePath(fileName)) {
          zip.close();
          return reject(new ZipValidationError(`Unsafe path in archive: ${fileName}`));
        }

        const targetPath = path.join(destDir, fileName);
        const resolvedTarget = path.resolve(targetPath);
        const resolvedDest = path.resolve(destDir);
        if (!resolvedTarget.startsWith(resolvedDest + path.sep) && resolvedTarget !== resolvedDest) {
          zip.close();
          return reject(new ZipValidationError(`Path traversal attempt detected: ${fileName}`));
        }

        // Reject unix symlinks encoded via external file attributes.
        const isSymlink = ((entry.externalFileAttributes >>> 16) & 0o170000) === 0o120000;
        if (isSymlink) {
          zip.close();
          return reject(new ZipValidationError(`Symlinks are not allowed in uploaded archives: ${fileName}`));
        }

        if (/\/$/.test(fileName)) {
          fs.mkdirSync(resolvedTarget, { recursive: true });
          zip.readEntry();
          return;
        }

        fs.mkdirSync(path.dirname(resolvedTarget), { recursive: true });
        zip.openReadStream(entry, (streamErr, readStream) => {
          if (streamErr || !readStream) {
            zip.close();
            return reject(new ZipValidationError(`Failed to read entry: ${fileName}`));
          }
          const writeStream = fs.createWriteStream(resolvedTarget, { mode: 0o644 });
          readStream.pipe(writeStream);
          writeStream.on("finish", () => zip.readEntry());
          writeStream.on("error", (e) => {
            zip.close();
            reject(e);
          });
        });
      });

      zip.on("end", () => resolve());
      zip.on("error", (e) => reject(e));
    });
  });
}
