import Docker from "dockerode";
import { config } from "../config.js";

const docker = new Docker({ socketPath: "/var/run/docker.sock" });

export interface RunOptions {
  image: string;
  workdirHostPath: string; // bind-mounted as /workspace inside the container
  command: string[]; // e.g. ["bash", "-lc", "npm install && ..."]
  env?: Record<string, string>;
  timeoutMs: number;
  onLog: (chunk: string) => void;
  signal: AbortSignal;
}

export interface RunResult {
  exitCode: number;
  timedOut: boolean;
}

/**
 * Runs a single build step inside a fresh, locked-down, non-privileged
 * container. Only /workspace (the extracted project) is mounted; nothing
 * else on the host is exposed. No Docker socket, no host network beyond
 * what's needed to fetch packages, no extra Linux capabilities.
 */
export async function runInContainer(opts: RunOptions): Promise<RunResult> {
  const container = await docker.createContainer({
    Image: opts.image,
    Cmd: opts.command,
    Env: Object.entries(opts.env || {}).map(([k, v]) => `${k}=${v}`),
    WorkingDir: "/workspace",
    HostConfig: {
      Binds: [`${opts.workdirHostPath}:/workspace:rw`],
      AutoRemove: false,
      NetworkMode: "bridge", // package managers need registry access; no host network
      Privileged: false,
      CapDrop: ["ALL"],
      CapAdd: ["CHOWN", "SETUID", "SETGID", "DAC_OVERRIDE"], // minimum needed for npm/gradle file ops
      SecurityOpt: ["no-new-privileges"],
      PidsLimit: config.containerPidsLimit,
      Memory: parseMemToBytes(config.containerMemory),
      NanoCpus: Math.round(parseFloat(config.containerCpus) * 1e9),
      ReadonlyRootfs: false, // build tools need to write temp/cache dirs outside /workspace too
      Tmpfs: { "/tmp": "rw,size=2g" },
    },
    Tty: false,
  });

  let timedOut = false;
  const timeout = setTimeout(async () => {
    timedOut = true;
    try {
      await container.stop({ t: 5 });
    } catch {
      /* already stopped */
    }
  }, opts.timeoutMs);

  const onAbort = async () => {
    try {
      await container.stop({ t: 5 });
    } catch {
      /* ignore */
    }
  };
  opts.signal.addEventListener("abort", onAbort);

  try {
    await container.start();

    const stream = await container.attach({ stream: true, stdout: true, stderr: true });
    stream.on("data", (chunk: Buffer) => {
      // Docker multiplexes stdout/stderr with an 8-byte header per frame.
      let offset = 0;
      while (offset < chunk.length) {
        if (chunk.length - offset < 8) break;
        const size = chunk.readUInt32BE(offset + 4);
        const payload = chunk.slice(offset + 8, offset + 8 + size).toString("utf-8");
        if (payload) opts.onLog(payload);
        offset += 8 + size;
      }
    });

    const waitResult = await container.wait();
    clearTimeout(timeout);
    opts.signal.removeEventListener("abort", onAbort);

    return { exitCode: waitResult.StatusCode ?? -1, timedOut };
  } finally {
    clearTimeout(timeout);
    opts.signal.removeEventListener("abort", onAbort);
    try {
      await container.remove({ force: true });
    } catch {
      /* already removed */
    }
  }
}

function parseMemToBytes(s: string): number {
  const m = /^(\d+(?:\.\d+)?)\s*(g|m|k)?b?$/i.exec(s.trim());
  if (!m) return 4 * 1024 ** 3;
  const n = parseFloat(m[1]);
  const unit = (m[2] || "g").toLowerCase();
  const mult = unit === "g" ? 1024 ** 3 : unit === "m" ? 1024 ** 2 : 1024;
  return Math.round(n * mult);
}

export { docker };
