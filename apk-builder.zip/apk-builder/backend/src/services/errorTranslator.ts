interface Rule {
  pattern: RegExp;
  explanation: string;
}

const RULES: Rule[] = [
  {
    pattern: /Unsupported class file major version/i,
    explanation: "The project requires a different Java version than the current build environment. Try adjusting JAVA_VERSION.",
  },
  {
    pattern: /SDK location not found|ANDROID_HOME/i,
    explanation: "The Android SDK could not be located inside the build container. This usually indicates a builder-image configuration issue.",
  },
  {
    pattern: /Could not find method|Could not resolve/i,
    explanation: "Gradle could not resolve a dependency or plugin, often due to a version mismatch or unreachable repository.",
  },
  {
    pattern: /ENOSPC|no space left on device/i,
    explanation: "The build server ran out of disk space. An administrator should free up space or increase storage.",
  },
  {
    pattern: /OutOfMemoryError|heap space/i,
    explanation: "The build ran out of memory. Try increasing the container memory limit or reducing build parallelism.",
  },
  {
    pattern: /npm ERR!|ENOENT.*package\.json/i,
    explanation: "Dependency installation failed. Check that package.json and the lockfile are valid and consistent.",
  },
  {
    pattern: /expo prebuild.*failed|Invalid app\.json/i,
    explanation: "Expo could not generate the native Android project from your app.json/app.config — check your Expo configuration.",
  },
  {
    pattern: /No matching version found for expo/i,
    explanation: "The installed Expo SDK version does not match what your dependencies require.",
  },
  {
    pattern: /Execution failed for task ':app:.*[Ll]int/i,
    explanation: "A Gradle lint task failed. Check the detailed logs for the specific lint error.",
  },
  {
    pattern: /Permission denied.*gradlew/i,
    explanation: "The Gradle wrapper script was not executable; the build system attempts to chmod it automatically — check archive contents.",
  },
];

export function friendlyError(technicalMessage: string): string {
  for (const rule of RULES) {
    if (rule.pattern.test(technicalMessage)) return rule.explanation;
  }
  return "The build failed. See the detailed logs for the exact error.";
}
