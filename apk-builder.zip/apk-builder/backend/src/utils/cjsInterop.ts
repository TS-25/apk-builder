import { createRequire } from "node:module";

const nodeRequire = createRequire(import.meta.url);

/**
 * Loads a CommonJS package via Node's own `require`, bypassing TypeScript's
 * static import resolution entirely.
 *
 * Why this exists: a couple of dependencies (`ioredis`, `pino-http`) ship
 * `.d.ts` files written with ES `export default` syntax even though the
 * published package is CJS. Under `moduleResolution: NodeNext`, neither a
 * plain `import X from "pkg"` nor `import X = require("pkg")` resolves the
 * *type* of X to the actual default export in that situation — both end up
 * typed as the whole module namespace object, which has no call/construct
 * signature, even though the runtime value works fine. `createRequire`
 * sidesteps the problem completely: its return type is untyped (`any`), so
 * there's nothing for the type checker to get wrong. We still unwrap
 * `.default` at runtime in case the package's CJS build set one (which is
 * exactly the situation that confuses the type checker in the first place).
 */
export function loadCjs<T = any>(specifier: string): T {
  const mod = nodeRequire(specifier);
  return (mod && typeof mod === "object" && "default" in mod ? mod.default : mod) as T;
}
