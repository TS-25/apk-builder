import pino from "pino";

const REDACT_PATHS = [
  "req.headers.authorization",
  "req.headers.cookie",
  "*.password",
  "*.passwordHash",
  "*.token",
  "*.apiKey",
  "*.secret",
];

export const logger = pino({
  level: process.env.LOG_LEVEL || "info",
  redact: { paths: REDACT_PATHS, censor: "[REDACTED]" },
});
