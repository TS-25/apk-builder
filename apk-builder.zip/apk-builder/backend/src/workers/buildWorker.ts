import { Worker } from "bullmq";
import fs from "node:fs";
import path from "node:path";
import { config } from "../config.js";
import { connection, type BuildJobData } from "../queue/queue.js";
import { publishLog } from "../queue/logBus.js";
import { subscribeCancel } from "../queue/cancelBus.js";
import { buildsRepo, logsRepo, outputsRepo } from "../database/db.js";
import { extractZipSafely } from "../security/zipValidator.js";
import { detectProject } from "../builders/detector.js";
import { getBuilderFor } from "../builders/registry.js";
import { BuildTimeoutError } from "../builders/AndroidBuilder.js";
import { logger } from "../utils/logger.js";
import { friendlyError } from "../services/errorTranslator.js";

function log(buildId: string, message: string, level: "info" | "warn" | "error" = "info") {
  logsRepo.append(buildId, message, level);
  publishLog({ buildId, message, level });
}

function setStage(buildId: string, stage: string, status?: any) {
  buildsRepo.updateStatus(buildId, (status ?? stage) as any, stage);
  publishLog({ buildId, message: `Stage: ${stage}`, level: "info", stage, status: status ?? stage });
}

// Tracks the AbortController for every build this worker process currently
// has in flight, so a cancel signal received over Redis (published by the
// `web` process, which has no Docker socket access of its own) can abort
// the right build and let this worker stop its own container.
const activeControllers = new Map<string, AbortController>();

subscribeCancel((buildId) => {
  const controller = activeControllers.get(buildId);
  if (controller) controller.abort();
});

async function processBuild(buildId: string) {
  const rec = buildsRepo.get(buildId);
  if (!rec) throw new Error(`Build ${buildId} not found`);

  const controller = new AbortController();
  activeControllers.set(buildId, controller);
  const timeoutGuard = setTimeout(() => controller.abort(), config.buildTimeoutMs + 5_000);

  try {
    buildsRepo.setStarted(buildId);

    setStage(buildId, "EXTRACTING");
    log(buildId, "Extracting uploaded archive...");
    const zipPath = path.join(rec.source_path, "..", "upload.zip");
    fs.mkdirSync(rec.source_path, { recursive: true });
    await extractZipSafely(zipPath, rec.source_path);
    log(buildId, "Extraction complete");

    setStage(buildId, "DETECTING");
    const info = detectProject(rec.source_path);
    buildsRepo.setProjectType(buildId, info.type);
    buildsRepo.setMeta(buildId, info as any);
    log(buildId, `Project detected: ${info.type}`);
    log(buildId, `Package manager: ${info.packageManager ?? "n/a"}`);
    if (info.type === "UNKNOWN") {
      throw new Error(
        "Could not detect a supported project type (Android/Expo/React Native markers not found)"
      );
    }

    setStage(buildId, "PREPARING");
    fs.mkdirSync(rec.output_path, { recursive: true });
    const builder = getBuilderFor(info);
    log(buildId, `Using builder: ${builder.type}`);

    const outputs = await builder.build(
      {
        buildId,
        sourceDir: rec.source_path,
        outputDir: rec.output_path,
        logDir: rec.log_path,
        onLog: (line, level) => log(buildId, line, level ?? "info"),
        onStage: (stage) => setStage(buildId, stage, stage === "BUILDING" ? "BUILDING" : undefined),
        signal: controller.signal,
      },
      info
    );

    for (const o of outputs) {
      outputsRepo.insert(buildId, o.filename, o.path, o.sizeBytes, o.variant);
      log(buildId, `APK found: ${o.filename} (${(o.sizeBytes / (1024 * 1024)).toFixed(1)} MB)`);
    }

    buildsRepo.setCompleted(buildId, "SUCCESS");
    publishLog({ buildId, message: "Build complete", level: "info", status: "SUCCESS", done: true });
  } catch (err: any) {
    clearTimeout(timeoutGuard);
    if (controller.signal.aborted && !(err instanceof BuildTimeoutError)) {
      buildsRepo.setCompleted(buildId, "CANCELLED", "Build was cancelled");
      log(buildId, "Build cancelled", "warn");
      publishLog({ buildId, message: "Build cancelled", level: "warn", status: "CANCELLED", done: true });
      return;
    }
    const isTimeout = err instanceof BuildTimeoutError;
    const status = isTimeout ? "TIMEOUT" : "FAILED";
    const friendly = friendlyError(err?.message || String(err));
    buildsRepo.setCompleted(buildId, status, friendly);
    log(buildId, `Build failed: ${err?.message || err}`, "error");
    log(buildId, `Explanation: ${friendly}`, "error");
    publishLog({ buildId, message: "Build failed", level: "error", status, done: true });
  } finally {
    clearTimeout(timeoutGuard);
    activeControllers.delete(buildId);
  }
}

const worker = new Worker<BuildJobData>(
  "builds",
  async (job) => {
    await processBuild(job.data.buildId);
  },
  { connection, concurrency: config.maxConcurrentBuilds }
);

worker.on("failed", (job, err) => {
  logger.error({ jobId: job?.id, err: err?.message }, "build job failed");
});

logger.info(`Build worker started (concurrency=${config.maxConcurrentBuilds})`);
