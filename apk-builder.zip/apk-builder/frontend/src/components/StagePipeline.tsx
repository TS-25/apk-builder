import { STAGES } from "../lib/api";

interface Props {
  currentStage: string;
  status: string;
}

const LABELS: Record<string, string> = {
  QUEUED: "Queued",
  EXTRACTING: "Extract",
  DETECTING: "Detect",
  PREPARING: "Prepare",
  INSTALLING_DEPENDENCIES: "Dependencies",
  PREBUILD: "Prebuild",
  BUILDING: "Build",
  FINDING_APK: "Locate APK",
  SUCCESS: "Complete",
};

/**
 * Stage-based progress — deliberately not a fake percentage. We only know
 * which discrete stage the build is in, so that's what we show.
 */
export default function StagePipeline({ currentStage, status }: Props) {
  const failed = ["FAILED", "CANCELLED", "TIMEOUT", "CANCELLING"].includes(status);
  const currentIndex = STAGES.indexOf(currentStage as (typeof STAGES)[number]);

  return (
    <div className="pipeline">
      {STAGES.map((stage, i) => {
        let cls = "stage";
        if (failed && i === currentIndex) cls += " failed";
        else if (i < currentIndex || status === "SUCCESS") cls += " done";
        else if (i === currentIndex) cls += " current";
        return (
          <div className={cls} key={stage}>
            {LABELS[stage] ?? stage}
          </div>
        );
      })}
    </div>
  );
}
