import { useEffect, useMemo, useRef, useState } from "react";
import type { LogLine } from "../lib/api";

interface Props {
  lines: LogLine[];
  title?: string;
}

/**
 * Terminal-style log viewer: auto-scroll (pausable), search with
 * highlighting, copy, download, and clear-display. Error/warning lines are
 * colored via the .line.warn / .line.error CSS rules.
 */
export default function Terminal({ lines, title = "build log" }: Props) {
  const [autoScroll, setAutoScroll] = useState(true);
  const [query, setQuery] = useState("");
  const [cleared, setCleared] = useState(false);
  const bodyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (autoScroll && bodyRef.current) {
      bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
    }
  }, [lines, autoScroll]);

  const visible = cleared ? [] : lines;

  const filtered = useMemo(() => {
    if (!query.trim()) return visible;
    const q = query.toLowerCase();
    return visible.filter((l) => l.message.toLowerCase().includes(q));
  }, [visible, query]);

  function highlight(text: string) {
    if (!query.trim()) return text;
    const idx = text.toLowerCase().indexOf(query.toLowerCase());
    if (idx === -1) return text;
    return (
      <>
        {text.slice(0, idx)}
        <mark>{text.slice(idx, idx + query.length)}</mark>
        {text.slice(idx + query.length)}
      </>
    );
  }

  function copyLogs() {
    navigator.clipboard.writeText(visible.map((l) => l.message).join("\n")).catch(() => {});
  }

  function downloadLogs() {
    const blob = new Blob([visible.map((l) => `[${l.ts ?? ""}] ${l.message}`).join("\n")], {
      type: "text/plain",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "build.log";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="terminal">
      <div className="terminal-head">
        <span className="title">{title}</span>
        <div className="actions">
          <input
            placeholder="search..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            style={{
              background: "transparent",
              border: "1px solid var(--line)",
              borderRadius: 5,
              color: "var(--text)",
              fontSize: 11,
              padding: "4px 8px",
              width: 110,
            }}
          />
          <button className={autoScroll ? "active" : ""} onClick={() => setAutoScroll((v) => !v)}>
            {autoScroll ? "auto-scroll on" : "auto-scroll off"}
          </button>
          <button onClick={copyLogs}>copy</button>
          <button onClick={downloadLogs}>download</button>
          <button onClick={() => setCleared((v) => !v)}>{cleared ? "restore" : "clear"}</button>
        </div>
      </div>
      <div className="terminal-body" ref={bodyRef}>
        {filtered.length === 0 && <div style={{ color: "var(--text-dim)" }}>No log output yet…</div>}
        {filtered.map((l, i) => (
          <div className={`line ${l.level}`} key={i}>
            {l.ts && <span className="ts">{new Date(l.ts.includes("Z") ? l.ts : l.ts + "Z").toLocaleTimeString()}</span>}
            <span>{highlight(l.message)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
