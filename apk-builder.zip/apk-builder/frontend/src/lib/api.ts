export interface BuildOutput {
  id: number;
  filename: string;
  path: string;
  size_bytes: number;
  variant: string | null;
  created_at: string;
}

export interface BuildRecord {
  id: string;
  project_name: string;
  project_type: string;
  status: string;
  stage: string;
  error_message: string | null;
  meta_json: string;
  created_at: string;
  started_at: string | null;
  completed_at: string | null;
  outputs?: BuildOutput[];
}

export interface LogLine {
  message: string;
  level: "info" | "warn" | "error";
  ts?: string;
}

const BASE = "/api";

async function json<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const body = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(body.error || `Request failed (${res.status})`);
  }
  return res.json();
}

export const api = {
  listBuilds: () => fetch(`${BASE}/builds`).then((r) => json<BuildRecord[]>(r)),
  getBuild: (id: string) => fetch(`${BASE}/builds/${id}`).then((r) => json<BuildRecord>(r)),
  getLogs: (id: string) => fetch(`${BASE}/builds/${id}/logs`).then((r) => json<LogLine[]>(r)),
  cancelBuild: (id: string) => fetch(`${BASE}/builds/${id}/cancel`, { method: "POST" }).then((r) => json(r)),
  deleteBuild: (id: string) => fetch(`${BASE}/builds/${id}`, { method: "DELETE" }),
  downloadUrl: (id: string, filename: string) => `${BASE}/builds/${id}/download/${encodeURIComponent(filename)}`,
  streamUrl: (id: string) => `${BASE}/builds/${id}/stream`,

  upload(file: File, onProgress: (pct: number) => void): Promise<{ id: string; status: string }> {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", `${BASE}/builds`);
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100));
      };
      xhr.onload = () => {
        try {
          const body = JSON.parse(xhr.responseText);
          if (xhr.status >= 200 && xhr.status < 300) resolve(body);
          else reject(new Error(body.error || `Upload failed (${xhr.status})`));
        } catch {
          reject(new Error("Upload failed: invalid server response"));
        }
      };
      xhr.onerror = () => reject(new Error("Upload failed: network error"));
      const form = new FormData();
      form.append("project", file);
      form.append("projectName", file.name.replace(/\.zip$/i, ""));
      xhr.send(form);
    });
  },

  adminStats: () => fetch(`${BASE}/admin/stats`).then((r) => json<any>(r)),
};

export const STAGES = [
  "QUEUED",
  "EXTRACTING",
  "DETECTING",
  "PREPARING",
  "INSTALLING_DEPENDENCIES",
  "PREBUILD",
  "BUILDING",
  "FINDING_APK",
  "SUCCESS",
] as const;

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  const units = ["KB", "MB", "GB"];
  let v = n;
  let i = -1;
  do {
    v /= 1024;
    i++;
  } while (v >= 1024 && i < units.length - 1);
  return `${v.toFixed(1)} ${units[i]}`;
}

export function formatDuration(startedAt: string | null, completedAt: string | null): string {
  if (!startedAt) return "—";
  const start = new Date(startedAt.includes("Z") ? startedAt : startedAt + "Z").getTime();
  const end = completedAt ? new Date(completedAt.includes("Z") ? completedAt : completedAt + "Z").getTime() : Date.now();
  const secs = Math.max(0, Math.round((end - start) / 1000));
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}
