import { useEffect, useState } from "react";
import { api, formatBytes } from "../lib/api";

export default function AdminDashboard() {
  const [stats, setStats] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [cleaning, setCleaning] = useState(false);
  const [cleanupResult, setCleanupResult] = useState<number | null>(null);

  function refresh() {
    api
      .adminStats()
      .then(setStats)
      .catch((e) => setError(e.message));
  }

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 5000);
    return () => clearInterval(id);
  }, []);

  async function runCleanup() {
    setCleaning(true);
    setCleanupResult(null);
    try {
      const res = await fetch("/api/admin/cleanup", { method: "POST" }).then((r) => r.json());
      setCleanupResult(res.removed ?? 0);
      refresh();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setCleaning(false);
    }
  }

  if (error === "Authentication required") {
    return (
      <div className="panel">
        <h2>Authentication required</h2>
        <p className="subtitle">Sign in on the Settings page to view the admin dashboard.</p>
      </div>
    );
  }

  if (error) return <p style={{ color: "var(--red)" }}>{error}</p>;
  if (!stats) return <p className="subtitle">Loading…</p>;

  const memUsedPct = Math.round(((stats.resources.memoryTotalBytes - stats.resources.memoryFreeBytes) / stats.resources.memoryTotalBytes) * 100);
  const diskUsedPct =
    stats.resources.diskTotalBytes && stats.resources.diskFreeBytes
      ? Math.round(((stats.resources.diskTotalBytes - stats.resources.diskFreeBytes) / stats.resources.diskTotalBytes) * 100)
      : null;

  return (
    <div>
      <h1>Admin dashboard</h1>
      <p className="subtitle">Live server and build-fleet resource usage.</p>

      <div className="grid-stats">
        <div className="stat-card"><div className="n">{stats.builds.queueActive}</div><div className="l">Active builds</div></div>
        <div className="stat-card"><div className="n">{stats.builds.queueWaiting}</div><div className="l">Queued</div></div>
        <div className="stat-card"><div className="n">{stats.resources.activeBuildContainers}</div><div className="l">Build containers</div></div>
        <div className="stat-card"><div className="n">{stats.resources.cpuCount}</div><div className="l">CPU cores</div></div>
        <div className="stat-card"><div className="n">{memUsedPct}%</div><div className="l">Memory used</div></div>
        {diskUsedPct !== null && <div className="stat-card"><div className="n">{diskUsedPct}%</div><div className="l">Disk used</div></div>}
      </div>

      <div className="two-col">
        <div className="panel">
          <h2>Builds by status</h2>
          {Object.entries(stats.builds.byStatus).map(([status, count]) => (
            <div className="field-row" key={status}>
              <span className="k"><span className={`badge ${status}`}>{status}</span></span>
              <span className="v">{count as number}</span>
            </div>
          ))}
        </div>

        <div className="panel">
          <h2>Resources</h2>
          <div className="field-row"><span className="k">CPU load (1m)</span><span className="v">{stats.resources.cpuLoadAvg[0].toFixed(2)}</span></div>
          <div className="field-row"><span className="k">Memory</span><span className="v">{formatBytes(stats.resources.memoryTotalBytes - stats.resources.memoryFreeBytes)} / {formatBytes(stats.resources.memoryTotalBytes)}</span></div>
          {stats.resources.diskTotalBytes && (
            <div className="field-row"><span className="k">Disk</span><span className="v">{formatBytes(stats.resources.diskTotalBytes - stats.resources.diskFreeBytes)} / {formatBytes(stats.resources.diskTotalBytes)}</span></div>
          )}
          <div className="field-row"><span className="k">Max concurrent builds</span><span className="v">{stats.config.maxConcurrentBuilds}</span></div>
          <div className="field-row"><span className="k">Build timeout</span><span className="v">{Math.round(stats.config.buildTimeoutMs / 60000)}m</span></div>
          <div className="field-row"><span className="k">Retention</span><span className="v">{stats.config.buildRetentionDays} days</span></div>
        </div>
      </div>

      <div className="panel" style={{ marginTop: 20 }}>
        <h2>Cleanup</h2>
        <p className="subtitle">Remove finished builds older than the configured retention period. Running builds are never touched.</p>
        <button className="btn secondary" disabled={cleaning} onClick={runCleanup}>
          {cleaning ? "Cleaning…" : "Run cleanup now"}
        </button>
        {cleanupResult !== null && <p className="subtitle" style={{ marginTop: 10 }}>Removed {cleanupResult} old build(s).</p>}
      </div>
    </div>
  );
}
