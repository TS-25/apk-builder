import { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { api, formatBytes, formatDuration, type BuildRecord, type LogLine } from "../lib/api";
import Terminal from "../components/Terminal";
import StagePipeline from "../components/StagePipeline";

const TERMINAL_STATUSES = ["SUCCESS", "FAILED", "CANCELLED", "TIMEOUT"];

export default function BuildDetails() {
  const { id } = useParams<{ id: string }>();
  const [build, setBuild] = useState<BuildRecord | null>(null);
  const [lines, setLines] = useState<LogLine[]>([]);
  const [error, setError] = useState<string | null>(null);
  const esRef = useRef<EventSource | null>(null);

  // Poll the build record (status, stage, outputs) — cheap and simple.
  useEffect(() => {
    if (!id) return;
    let cancelled = false;
    let timer: ReturnType<typeof setTimeout>;

    async function poll() {
      try {
        const rec = await api.getBuild(id!);
        if (cancelled) return;
        setBuild(rec);
        if (!TERMINAL_STATUSES.includes(rec.status)) {
          timer = setTimeout(poll, 2000);
        }
      } catch (e: any) {
        if (!cancelled) setError(e.message);
      }
    }
    poll();
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [id]);

  // Stream logs live over SSE; replays history then appends new lines.
  useEffect(() => {
    if (!id) return;
    setLines([]);
    const es = new EventSource(api.streamUrl(id));
    esRef.current = es;
    es.onmessage = (evt) => {
      try {
        const data = JSON.parse(evt.data);
        if (data.message) {
          setLines((prev) => [...prev, { message: data.message, level: data.level ?? "info", ts: data.ts }]);
        }
        if (data.done) es.close();
      } catch {
        /* ignore */
      }
    };
    es.onerror = () => es.close();
    return () => es.close();
  }, [id]);

  async function cancel() {
    if (!id) return;
    try {
      await api.cancelBuild(id);
    } catch (e: any) {
      setError(e.message);
    }
  }

  if (error) return <p style={{ color: "var(--red)" }}>{error}</p>;
  if (!build) return <p className="subtitle">Loading build…</p>;

  const meta = safeParse(build.meta_json);
  const running = !TERMINAL_STATUSES.includes(build.status) && build.status !== "CANCELLING";
  const cancellable = running || build.status === "QUEUED";

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <h1>{build.project_name}</h1>
          <p className="subtitle">
            Build <span style={{ fontFamily: "var(--font-mono)" }}>{build.id}</span>
          </p>
        </div>
        <span className={`badge ${build.status}`}>{build.status}</span>
      </div>

      {build.status === "SUCCESS" && (
        <div className="panel" style={{ borderColor: "var(--green)", marginBottom: 20 }}>
          <h2 style={{ color: "var(--green)" }}>✓ Build successful</h2>
          {(build.outputs ?? []).map((o) => (
            <div className="field-row" key={o.id}>
              <span className="k">{o.filename} <span className="subtitle">({o.variant ?? "apk"})</span></span>
              <span className="v">
                {formatBytes(o.size_bytes)}{" "}
                <a className="btn" style={{ marginLeft: 10, padding: "4px 10px", fontSize: 12 }} href={api.downloadUrl(build.id, o.filename)}>
                  Download
                </a>
              </span>
            </div>
          ))}
        </div>
      )}

      {["FAILED", "TIMEOUT"].includes(build.status) && (
        <div className="panel" style={{ borderColor: "var(--red)", marginBottom: 20 }}>
          <h2 style={{ color: "var(--red)" }}>✗ Build {build.status === "TIMEOUT" ? "timed out" : "failed"}</h2>
          <p>{build.error_message || "See detailed logs below for the exact error."}</p>
        </div>
      )}

      <div className="two-col">
        <div>
          <div className="panel" style={{ marginBottom: 16 }}>
            <h2>Progress</h2>
            <StagePipeline currentStage={build.stage} status={build.status} />
          </div>

          <div className="panel">
            <h2>Project info</h2>
            <div className="field-row"><span className="k">Type</span><span className="v">{build.project_type}</span></div>
            {meta?.packageId && <div className="field-row"><span className="k">Package</span><span className="v">{meta.packageId}</span></div>}
            {meta?.appVersion && <div className="field-row"><span className="k">Version</span><span className="v">{meta.appVersion}</span></div>}
            {meta?.expoSdkVersion && <div className="field-row"><span className="k">Expo SDK</span><span className="v">{meta.expoSdkVersion}</span></div>}
            {meta?.nodeVersion && <div className="field-row"><span className="k">Node</span><span className="v">{meta.nodeVersion}</span></div>}
            {meta?.packageManager && <div className="field-row"><span className="k">Package manager</span><span className="v">{meta.packageManager}</span></div>}
            <div className="field-row"><span className="k">Duration</span><span className="v">{formatDuration(build.started_at, build.completed_at)}</span></div>
          </div>

          {cancellable && (
            <button className="btn danger" style={{ marginTop: 16, width: "100%" }} onClick={cancel}>
              Cancel build
            </button>
          )}
        </div>

        <Terminal lines={lines} title={`build ${build.id} — live log`} />
      </div>
    </div>
  );
}

function safeParse(json: string): any {
  try {
    return JSON.parse(json);
  } catch {
    return null;
  }
}
