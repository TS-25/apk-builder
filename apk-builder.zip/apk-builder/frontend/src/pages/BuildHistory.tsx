import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, formatDuration, type BuildRecord } from "../lib/api";

const ACTIVE = ["QUEUED", "UPLOADING", "EXTRACTING", "DETECTING", "PREPARING", "INSTALLING_DEPENDENCIES", "PREBUILD", "BUILDING", "FINDING_APK", "CANCELLING"];

export default function BuildHistory() {
  const [builds, setBuilds] = useState<BuildRecord[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  function refresh() {
    api.listBuilds().then(setBuilds).catch((e) => setError(e.message));
  }

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 5000);
    return () => clearInterval(id);
  }, []);

  async function handleCancel(id: string) {
    setBusyId(id);
    try {
      await api.cancelBuild(id);
      refresh();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusyId(null);
    }
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this build and all its files? This cannot be undone.")) return;
    setBusyId(id);
    try {
      await api.deleteBuild(id);
      refresh();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <h1>Build history</h1>
      <p className="subtitle">Every build ever run on this server.</p>

      {error && <p style={{ color: "var(--red)" }}>{error}</p>}

      <div className="panel">
        {builds.length === 0 ? (
          <div className="empty-state">
            No builds yet. <Link to="/upload">Upload a project</Link> to get started.
          </div>
        ) : (
          <table className="history">
            <thead>
              <tr>
                <th>Build ID</th>
                <th>Project</th>
                <th>Type</th>
                <th>Status</th>
                <th>Created</th>
                <th>Duration</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {builds.map((b) => (
                <tr key={b.id}>
                  <td style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>{b.id}</td>
                  <td>{b.project_name}</td>
                  <td>{b.project_type}</td>
                  <td><span className={`badge ${b.status}`}>{b.status}</span></td>
                  <td>{new Date(b.created_at.includes("Z") ? b.created_at : b.created_at + "Z").toLocaleString()}</td>
                  <td>{formatDuration(b.started_at, b.completed_at)}</td>
                  <td style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
                    <Link to={`/builds/${b.id}`}>View</Link>
                    {ACTIVE.includes(b.status) ? (
                      <button
                        className="btn secondary"
                        style={{ padding: "3px 9px", fontSize: 12 }}
                        disabled={busyId === b.id}
                        onClick={() => handleCancel(b.id)}
                      >
                        Cancel
                      </button>
                    ) : (
                      <button
                        className="btn secondary"
                        style={{ padding: "3px 9px", fontSize: 12 }}
                        disabled={busyId === b.id}
                        onClick={() => handleDelete(b.id)}
                      >
                        Delete
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
