import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, type BuildRecord, formatDuration } from "../lib/api";

export default function Dashboard() {
  const [builds, setBuilds] = useState<BuildRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    api
      .listBuilds()
      .then((rows) => !cancelled && setBuilds(rows))
      .catch((e) => !cancelled && setError(e.message))
      .finally(() => !cancelled && setLoading(false));
    const id = setInterval(() => api.listBuilds().then((rows) => !cancelled && setBuilds(rows)).catch(() => {}), 4000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, []);

  const total = builds.length;
  const success = builds.filter((b) => b.status === "SUCCESS").length;
  const failed = builds.filter((b) => ["FAILED", "TIMEOUT"].includes(b.status)).length;
  const running = builds.filter((b) =>
    ["BUILDING", "PREPARING", "INSTALLING_DEPENDENCIES", "PREBUILD", "EXTRACTING", "DETECTING", "FINDING_APK"].includes(b.status)
  ).length;
  const queued = builds.filter((b) => b.status === "QUEUED").length;

  return (
    <div>
      <h1>Dashboard</h1>
      <p className="subtitle">Self-hosted APK build platform — Android, Expo &amp; React Native.</p>

      <div className="grid-stats">
        <div className="stat-card"><div className="n">{total}</div><div className="l">Total builds</div></div>
        <div className="stat-card"><div className="n" style={{ color: "var(--green)" }}>{success}</div><div className="l">Successful</div></div>
        <div className="stat-card"><div className="n" style={{ color: "var(--red)" }}>{failed}</div><div className="l">Failed</div></div>
        <div className="stat-card"><div className="n" style={{ color: "var(--amber)" }}>{running}</div><div className="l">Running</div></div>
        <div className="stat-card"><div className="n">{queued}</div><div className="l">Queued</div></div>
      </div>

      <div className="panel">
        <h2>Recent builds</h2>
        {loading && <p className="subtitle">Loading…</p>}
        {error && <p style={{ color: "var(--red)" }}>{error}</p>}
        {!loading && builds.length === 0 && (
          <div className="empty-state">
            No builds yet. <Link to="/upload">Upload a project</Link> to start your first build.
          </div>
        )}
        {builds.length > 0 && (
          <table className="history">
            <thead>
              <tr>
                <th>Project</th>
                <th>Type</th>
                <th>Status</th>
                <th>Duration</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {builds.slice(0, 8).map((b) => (
                <tr key={b.id}>
                  <td>{b.project_name}</td>
                  <td>{b.project_type}</td>
                  <td><span className={`badge ${b.status}`}>{b.status}</span></td>
                  <td>{formatDuration(b.started_at, b.completed_at)}</td>
                  <td><Link to={`/builds/${b.id}`}>View →</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
