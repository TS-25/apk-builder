import { useState } from "react";

export default function Settings() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function login(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setMessage(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ email, password }),
      });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error || "Login failed");
      setMessage("Signed in. The Admin dashboard is now unlocked.");
    } catch (e: any) {
      setError(e.message);
    }
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
    setMessage("Signed out.");
  }

  return (
    <div>
      <h1>Settings</h1>
      <p className="subtitle">Admin sign-in and server configuration reference.</p>

      <div className="two-col">
        <div className="panel">
          <h2>Admin sign-in</h2>
          <p className="subtitle">
            Only required if <span style={{ fontFamily: "var(--font-mono)" }}>ADMIN_EMAIL</span> /{" "}
            <span style={{ fontFamily: "var(--font-mono)" }}>ADMIN_PASSWORD_HASH</span> are set on the server.
          </p>
          <form onSubmit={login}>
            <div style={{ marginBottom: 12 }}>
              <label className="subtitle" style={{ display: "block", marginBottom: 6 }}>Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                style={{ width: "100%", padding: "8px 10px", background: "var(--panel-raised)", border: "1px solid var(--line)", borderRadius: 6, color: "var(--text)" }}
              />
            </div>
            <div style={{ marginBottom: 16 }}>
              <label className="subtitle" style={{ display: "block", marginBottom: 6 }}>Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                style={{ width: "100%", padding: "8px 10px", background: "var(--panel-raised)", border: "1px solid var(--line)", borderRadius: 6, color: "var(--text)" }}
              />
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn" type="submit">Sign in</button>
              <button className="btn secondary" type="button" onClick={logout}>Sign out</button>
            </div>
          </form>
          {message && <p style={{ color: "var(--green)", marginTop: 12 }}>{message}</p>}
          {error && <p style={{ color: "var(--red)", marginTop: 12 }}>{error}</p>}
        </div>

        <div className="panel">
          <h2>About this server</h2>
          <p className="subtitle">
            Build limits, timeouts, Java/Android SDK/Node versions, and retention are configured via
            environment variables on the server (see <span style={{ fontFamily: "var(--font-mono)" }}>.env</span>)
            and shown live on the Admin dashboard.
          </p>
          <div className="field-row"><span className="k">Supported project types</span><span className="v">Android, Expo, React Native</span></div>
          <div className="field-row"><span className="k">Build isolation</span><span className="v">Docker, non-privileged</span></div>
          <div className="field-row"><span className="k">Cloud build dependency</span><span className="v">None — fully self-hosted</span></div>
        </div>
      </div>
    </div>
  );
}
