import { useCallback, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, formatBytes } from "../lib/api";

export default function UploadPage() {
  const [file, setFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const pickFile = useCallback((f: File | null) => {
    setError(null);
    if (!f) return setFile(null);
    if (!f.name.toLowerCase().endsWith(".zip")) {
      setError("Only ZIP files are allowed.");
      return;
    }
    setFile(f);
  }, []);

  async function startBuild() {
    if (!file) return;
    setSubmitting(true);
    setError(null);
    setProgress(0);
    try {
      const result = await api.upload(file, setProgress);
      navigate(`/builds/${result.id}`);
    } catch (e: any) {
      setError(e.message || "Upload failed");
      setSubmitting(false);
      setProgress(null);
    }
  }

  return (
    <div>
      <h1>Upload project</h1>
      <p className="subtitle">
        Upload a ZIP of an Android, Expo, or React Native project. The build runs entirely on this
        server, inside an isolated Docker container — no cloud build service is used.
      </p>

      <div
        className={`dropzone ${dragging ? "drag" : ""}`}
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          pickFile(e.dataTransfer.files?.[0] ?? null);
        }}
      >
        <div className="icon">⬆</div>
        {file ? (
          <>
            <div style={{ fontFamily: "var(--font-mono)", marginBottom: 6 }}>{file.name}</div>
            <div className="subtitle" style={{ marginBottom: 12 }}>{formatBytes(file.size)}</div>
          </>
        ) : (
          <>
            <div style={{ marginBottom: 4 }}>Drop your project ZIP here</div>
            <div className="subtitle" style={{ marginBottom: 16 }}>or</div>
          </>
        )}
        <input
          ref={inputRef}
          type="file"
          accept=".zip"
          hidden
          onChange={(e) => pickFile(e.target.files?.[0] ?? null)}
        />
        <button className="btn secondary" onClick={() => inputRef.current?.click()}>
          Select ZIP
        </button>
      </div>

      {error && <p style={{ color: "var(--red)", marginTop: 16 }}>{error}</p>}

      {progress !== null && (
        <div className="panel" style={{ marginTop: 16 }}>
          <div className="field-row">
            <span className="k">Uploading…</span>
            <span className="v">{progress}%</span>
          </div>
        </div>
      )}

      <div style={{ marginTop: 24 }}>
        <button className="btn" disabled={!file || submitting} onClick={startBuild}>
          {submitting ? "Starting build…" : "Start Build"}
        </button>
      </div>
    </div>
  );
}
