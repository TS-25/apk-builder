# Sample Android project

A minimal, real Android app (single Activity, no dependencies beyond
AppCompat/Material) used to exercise the self-hosted Android build path
end-to-end.

This project intentionally ships **without** a Gradle wrapper
(`gradlew` / `gradle/wrapper/gradle-wrapper.jar`), since a wrapper jar is a
binary file and shipping one via a text-based repo/zip is unreliable. The
Android builder image includes its own system-wide Gradle install
(`GRADLE_VERSION`, see `docker/android-builder/Dockerfile`) and
`AndroidBuilder` automatically falls back to it whenever a project has no
`./gradlew` — so this project builds exactly the same way a real project
with a checked-in wrapper would.

If you want to test the "project's own wrapper" code path instead, generate
one locally and add it to the zip before uploading:

```bash
cd sample-projects/android
gradle wrapper --gradle-version 8.9
```

## Try it

```bash
cd sample-projects/android
zip -r ../sample-android.zip . -x '.git/*'
```

Upload `sample-android.zip` through the web UI (or `POST /api/builds`) and
you should get `app-debug.apk` back within a couple of minutes on first run
(subsequent runs are faster once Gradle's dependency cache is warm inside
the builder image).
