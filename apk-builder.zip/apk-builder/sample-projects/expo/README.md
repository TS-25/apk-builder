# Sample Expo project

A minimal Expo (managed) app used to exercise the self-hosted
Expo → `expo prebuild` → Gradle → APK workflow end-to-end.

No `android/` directory is checked in, so on upload `ExpoBuilder` will
correctly detect that native code needs to be generated and run
`npx expo prebuild --platform android` inside the isolated builder
container before invoking Gradle — exactly the workflow described in the
platform's Expo support section. No Expo account or Expo cloud build
service is used at any point.

## Try it

```bash
cd sample-projects/expo
zip -r ../sample-expo.zip . -x 'node_modules/*'
```

Upload `sample-expo.zip` through the web UI. Expect a longer first build
(dependency install + prebuild + Gradle) than the plain Android sample,
since Expo has to generate the native project from scratch.
