#!/usr/bin/env bash
# Builds the isolated builder images used by the worker to run untrusted
# project builds. These aren't long-running services (the worker spins up a
# fresh container from them per build via the Docker API), so they live
# outside docker-compose.yml and are built/rebuilt explicitly with this
# script — run it once during install and again whenever you bump
# JAVA_VERSION / ANDROID_* / NODE_VERSION in .env.
set -euo pipefail
cd "$(dirname "$0")/.."

# shellcheck disable=SC1091
[ -f .env ] && source .env

JAVA_VERSION="${JAVA_VERSION:-17}"
NODE_VERSION="${NODE_VERSION:-22}"
ANDROID_PLATFORM_VERSION="${ANDROID_PLATFORM_VERSION:-35}"
ANDROID_BUILD_TOOLS_VERSION="${ANDROID_BUILD_TOOLS_VERSION:-35.0.0}"
ANDROID_CMDLINE_TOOLS_VERSION="${ANDROID_CMDLINE_TOOLS_VERSION:-11076708}"

echo "==> Building apk-builder/android-builder:latest"
docker build \
  --build-arg ANDROID_PLATFORM_VERSION="$ANDROID_PLATFORM_VERSION" \
  --build-arg ANDROID_BUILD_TOOLS_VERSION="$ANDROID_BUILD_TOOLS_VERSION" \
  --build-arg ANDROID_CMDLINE_TOOLS_VERSION="$ANDROID_CMDLINE_TOOLS_VERSION" \
  -t apk-builder/android-builder:latest \
  ./docker/android-builder

echo "==> Building apk-builder/expo-builder:latest"
docker build \
  --build-arg NODE_VERSION="$NODE_VERSION" \
  --build-arg ANDROID_PLATFORM_VERSION="$ANDROID_PLATFORM_VERSION" \
  --build-arg ANDROID_BUILD_TOOLS_VERSION="$ANDROID_BUILD_TOOLS_VERSION" \
  --build-arg ANDROID_CMDLINE_TOOLS_VERSION="$ANDROID_CMDLINE_TOOLS_VERSION" \
  -t apk-builder/expo-builder:latest \
  ./docker/expo-builder

echo "==> Done. Builder images ready."
